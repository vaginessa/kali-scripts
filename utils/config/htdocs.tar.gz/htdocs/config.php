<?php 
if (!defined('sec')) {
	die();
}
$files = array();
$files[] = array('name' => 'Mana',
				'path'		=> dirname(__FILE__).'/files/hostapd-karma.conf',
				'include'	=> dirname(__FILE__).'/includes/file-0.php');

$files[] = array('name' => 'Bad USB',
				'path' => dirname(__FILE__).'/files/hosts',
				'include'	=> dirname(__FILE__).'/includes/file-2.php');

$files[] = array('name' => 'HID reverse-tcp', 
				'path' => dirname(__FILE__).'/files/rev-tcp',
				'include'	=> dirname(__FILE__).'/includes/file-1.php');

$files[] = array('name' => 'HID reverse-meterpreter',
				'path' => dirname(__FILE__).'/files/rev-met',
				'include'	=> dirname(__FILE__).'/includes/file-3.php');
asort($files);