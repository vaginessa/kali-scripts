<?php 
if (!defined('sec')) {
	die('Try harder!');
}
$files = array();

$files['badusb']				= array('path'		=> /sdcard/files/startbadusb.sh',
										'include'	=> dirname(__FILE__).'/includes/badusb.php');

$files['reversetcp']			= array('path'		=> '/sdcard/files/rev-tcp',
										'include'	=> dirname(__FILE__).'/includes/rtcppayload.php');

$files['dnsmasq']				= array('path'		=> '/sdcard/files/dnsmasq.conf',
										'include'	=> dirname(__FILE__).'/includes/dnsmasq.php');

$files['hostapd-config']		= array('path'		=> '/sdcard/files/hostapd.conf',
										'include'	=> dirname(__FILE__).'/includes/hostapd-config.php');

$files['dhcpd']					= array('path'		=> '/sdcard/files/dhcpd.conf',
										'include'	=> dirname(__FILE__).'/includes/dhcpd.php');

$files['hostapd-karma']			= array('path'		=> '/etc/mana-toolkit/hostapd-karma.conf',
										'include'	=> dirname(__FILE__).'/includes/hostapd-karma.php');

$files['dhcpd-mana']			= array('path'		=> '/sdcard/files/dhcpd.conf',
										'include'	=> dirname(__FILE__).'/includes/dhcpd-mana.php');


$files['dnsspoof']				= array('path'		=> '/etc/mana-toolkit/dnsspoof.conf',
										'include'	=> dirname(__FILE__).'/includes/dnsspoof.php');

$files['startmana']				= array('path'		=> '/data/local/kali-armhf/usr/share/mana-toolkit/run-mana/start-nat-full-mod.sh',
										'include'	=> dirname(__FILE__).'/includes/startmana.php');

$files['iptables']				= array('path'		=> '/sdcard/files/iptables.conf',
										'include'	=> dirname(__FILE__).'/includes/iptables.php');

$files['kaliservices']			= array('path'		=> '',
										'include'	=> dirname(__FILE__).'/includes/kaliservices.php');

$files['hid']					= array('path'		=> '',
										'include'	=> dirname(__FILE__).'/includes/hid.php');

$files['hid-cmd']				= array('path'		=>  '/sdcard/files/hid-cmd.conf',
										'include'	=> dirname(__FILE__).'/includes/hid-cmd.php');

$files['mana']					= array('path'		=> '',
										'include'	=> dirname(__FILE__).'/includes/mana.php');

$files['home']					= array('path'		=> '',
										'include'	=> dirname(__FILE__).'/includes/home.php');

$files['powersploit']			= array('path'		=>'/data/local/kali-armhf/var/www/payload',
										'path2'		=>'/sdcard/files/powersploit-url',
										'include'	=> dirname(__FILE__).'/includes/powersploit.php');
