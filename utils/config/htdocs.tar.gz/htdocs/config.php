<?php 
if (!defined('sec')) {
	die();
}
$files = array();
$files[] = array('name' => 'Mana Evil AP',
				'path'		=> dirname(__FILE__).'/files/hostapd-karma.conf',
				'include'	=> dirname(__FILE__).'/includes/file-0.php');

$files[] = array('name' => 'Bad USB Attack',
				'path' => dirname(__FILE__).'/files/hosts',
				'include'	=> dirname(__FILE__).'/includes/file-2.php');

$files[] = array('name' => 'HID rev-tcp', 
				'path' => dirname(__FILE__).'/files/rev-tcp',
				'include'	=> dirname(__FILE__).'/includes/file-1.php');

$files[] = array('name' => 'HID rev-met',
				'path' => dirname(__FILE__).'/files/rev-met',
				'include'	=> dirname(__FILE__).'/includes/file-3.php');

$files[] = array('name' => 'HID rev-met-https',
				'path' => dirname(__FILE__).'/files/rev-met-https',
				'include'	=> dirname(__FILE__).'/includes/rev_met_https.php');

$files[] = array('name' => 'DNSMASQ Config',
				'path' => dirname(__FILE__).'/files/dnsmasq.conf',
				'include'	=> dirname(__FILE__).'/includes/dnsmasq.php');

asort($files);
