<?php 
if (!defined('sec')) {
	die();
}
$files = array();
// $files['mana']					= array('path'		=> '/sdcard/htdocs/files/hostapd-karma.conf',
// 										'include'	=> dirname(__FILE__).'/includes/mana.php');

$files['badusb']				= array('path'		=> '/sdcard/htdocs/files/hosts',
										'include'	=> dirname(__FILE__).'/includes/badusb.php');

$files['reversetcp']			= array('path'		=> '/sdcard/htdocs/files/rev-tcp',
										'include'	=> dirname(__FILE__).'/includes/rtcppayload.php');

$files['reverse-meterpreter']	= array('path'		=> '/sdcard/htdocs/files/rev-met',
										'include'	=> dirname(__FILE__).'/includes/reverse-meterpreter.php');

$files['dnsmasq']				= array('path'		=> '/sdcard/htdocs/files/dnsmasq.conf',
										'include'	=> dirname(__FILE__).'/includes/dnsmasq.php');

$files['reverse-https']			= array('path'		=> '/sdcard/htdocs/files/rev-met-https',
										'include'	=> dirname(__FILE__).'/includes/rev_met_https.php');

$files['hostapd-config']		= array('path'		=> dirname(__FILE__).'/files/hostapd.conf',
										'include'	=> dirname(__FILE__).'/includes/hostapd-config.php');


$files['dhcpd']					= array('path'		=> dirname(__FILE__).'/files/dhcpd.conf',
										'include'	=> dirname(__FILE__).'/includes/dhcpd.php');

$files['hostapd-karma']			= array('path'		=> dirname(__FILE__).'/files/hostapd-karma.conf',
										'include'	=> dirname(__FILE__).'/includes/mana.php');

$files['dhcpd-mana']			= array('path'		=> dirname(__FILE__).'/files/dhcpd-mana.conf',
										'include'	=> dirname(__FILE__).'/includes/dhcpd-mana.php');


$files['dnsspoof']				= array('path'		=> dirname(__FILE__).'/files/dnsspoof.conf',
										'include'	=> dirname(__FILE__).'/includes/dnsspoof.php');

$files['iptables']				= array('path'		=> dirname(__FILE__).'/files/iptables.conf',
										'include'	=> dirname(__FILE__).'/includes/iptables.php');

$files['kaliservices']			= array('path'		=> '',
										'include'	=> dirname(__FILE__).'/includes/kaliservices.php');

$files['hid']					= array('path'		=> '',
										'include'	=> dirname(__FILE__).'/includes/hid.php');

$files['mana']					= array('path'		=> '',
										'include'	=> dirname(__FILE__).'/includes/mana-evil.php');

$files['home']					= array('path'		=> '',
										'include'	=> dirname(__FILE__).'/includes/home.php');
