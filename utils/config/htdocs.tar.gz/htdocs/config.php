<?php 
if (!defined('sec')) {
	die('Try harder!');
}
$files = array();
// $files['mana']					= array('path'		=> '/sdcard/files/hostapd-karma.conf',
// 										'include'	=> dirname(__FILE__).'/includes/mana.php');

$files['badusb']				= array('path'		=> dirname(__FILE__).'/files/startbadusb.sh',
										'include'	=> dirname(__FILE__).'/includes/badusb.php');

$files['reversetcp']			= array('path'		=> '/sdcard/files/rev-tcp',
										'include'	=> dirname(__FILE__).'/includes/rtcppayload.php');

/*
$files['reverse-meterpreter']	= array('path'		=> '/sdcard/files/rev-met',
										'include'	=> dirname(__FILE__).'/includes/reverse-meterpreter.php');
*/
$files['dnsmasq']				= array('path'		=> '/sdcard/files/dnsmasq.conf',
										'include'	=> dirname(__FILE__).'/includes/dnsmasq.php');
/*
$files['reverse-https']			= array('path'		=> '/sdcard/files/rev-met-https',
										'include'	=> dirname(__FILE__).'/includes/rev_met_https.php');
*/
$files['hostapd-config']		= array('path'		=> '/sdcard/files/hostapd.conf',
										'include'	=> dirname(__FILE__).'/includes/hostapd-config.php');


$files['dhcpd']					= array('path'		=> '/sdcard/files/dhcpd.conf',
										'include'	=> dirname(__FILE__).'/includes/dhcpd.php');

$files['hostapd-karma']			= array('path'		=> '/sdcard/files/hostapd-karma.conf',
										'include'	=> dirname(__FILE__).'/includes/hostapd-karma.php');

$files['dhcpd-mana']			= array('path'		=> '/sdcard/files/dhcpd-mana.conf',
										'include'	=> dirname(__FILE__).'/includes/dhcpd-mana.php');


$files['dnsspoof']				= array('path'		=> '/sdcard/files/dnsspoof.conf',
										'include'	=> dirname(__FILE__).'/includes/dnsspoof.php');

$files['startmana']				= array('path'		=> '/data/local/kali-armhf/root/mana/run-mana/start-nat-full.sh',
										//'path'		=> dirname(__FILE__).'/files/start-nat-full.sh',
										'include'	=> dirname(__FILE__).'/includes/startmana.php');


$files['iptables']				= array('path'		=> '/sdcard/files/iptables.conf',
										'include'	=> dirname(__FILE__).'/includes/iptables.php');

$files['kaliservices']			= array('path'		=> '',
										'include'	=> dirname(__FILE__).'/includes/kaliservices.php');

$files['hid']					= array('path'		=> '',
										'include'	=> dirname(__FILE__).'/includes/hid.php');

$files['hid-cmd']				= array('path'		=>  '/sdcard/files/hid-cmd.conf',
										'include'	=> dirname(__FILE__).'/includes/hid-cmd.php');

$files['mana']					= array('path'		=> '',
										'include'	=> dirname(__FILE__).'/includes/mana.php');

$files['home']					= array('path'		=> '',
										'include'	=> dirname(__FILE__).'/includes/home.php');

$files['powersploit']			= array('path'		=>'/data/local/kali-armhf/sdcard/files/powersploit-payload',
										'path2'		=>'/sdcard/files/powersploit-url',
										'include'	=> dirname(__FILE__).'/includes/powersploit.php');
