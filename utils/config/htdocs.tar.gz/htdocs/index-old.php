<?php 
	define('sec', 1);
	require dirname(__FILE__).'/config.php';
	if (isset($_REQUEST['k'])) {
		$key = trim(strip_tags($_REQUEST['k']));
	} else {
		$selected_k = key($files);
	}
	if (!empty($key) && isset($files[$key])) {
		$selected_k = $key;
	} else {
		$selected_k = key($files);
	}
?>
<!DOCTYPE html>
<html lang="en">
	<head>
	    <meta charset="utf-8">
	    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	    <meta name="viewport" content="width=device-width, initial-scale=1">
	    <meta name="description" content="">
	    <meta name="author" content="Offensive Security">
	    <title></title>
	    <link href="css/bootstrap.min.css" rel="stylesheet">
	    <link href="css/application.css" rel="stylesheet">
	</head>
	<body>
	    <div class="container-fluid">
			<div class="row">
				<div class="col-sm-3 col-md-2 sidebar" id="sidebar">
					<ul class="nav nav-sidebar">	            		
						<li class="<?php if ($selected_k === 'badusb'): echo "active"; endif;?>">
								<a href="index.php?k=badusb"><i class="oc-partial-icon icm icm-file"></i><span class="oc-partial-menu-item">Bad USB Attack</span></a>    
						</li>
						<li class="<?php if ($selected_k === 'dnsmasq'): echo "active"; endif;?>">
							<a href="index.php?k=dnsmasq"><i class="oc-partial-icon icm icm-file"></i><span class="oc-partial-menu-item">Dnsmasq Service</span></a>    
						</li>
						
						<li>
							<li class="<?php if ($selected_k === 'hid'): echo "active"; endif;?>">
							<a href="index.php?k=hid"><i class="oc-partial-icon icm icm-file"></i><span class="oc-partial-menu-item">HID keyboard Attack</span></a>    
						</li>
						<li>
							<li class="<?php if ($selected_k === 'hostapd-config'): echo "active"; endif;?>">
							<a href="index.php?k=hostapd-config"><i class="oc-partial-icon icm icm-file"></i><span class="oc-partial-menu-item">Hostapd config</span></a>    
						</li>
						<li class="<?php if ($selected_k === 'mana'): echo "active"; endif;?>">
							<a href="index.php?k=mana"><i class="oc-partial-icon icm icm-file"></i><span class="oc-partial-menu-item">Mana Evil Access Point</span></a>    
						</li>
						<li class="<?php if ($selected_k === 'kaliservices'): echo "active"; endif;?>">
							<a href="index.php?k=kaliservices"><i class="oc-partial-icon icm icm-file"></i><span class="oc-partial-menu-item">Kali services</span></a>    
						</li>
					</ul>
	        	</div>
				<div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
		          	<?php if (isset($files[$selected_k]['include']) && is_file($files[$selected_k]['include'])):?>
		          		<?php include $files[$selected_k]['include']; ?>
		          	<?php else: ?>
		          	
		          	<?php endif;?>
				</div> <!-- end of .main -->
			</div> <!-- end of .roe -->
		</div> <!-- end of .container-fluid -->
  
		<script src="js/jquery-1.11.1.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="js/scripts.js"></script>
	</body>  
</html>
