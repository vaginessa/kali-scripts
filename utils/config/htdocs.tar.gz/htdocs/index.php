<?php 
	define('sec', 1);
	require dirname(__FILE__).'/config.php';
	if (isset($_REQUEST['k']) && (int) $_REQUEST['k'] >= 0 && isset($files[(int) $_REQUEST['k']])) {
		$selected_k = (int) $_REQUEST['k'];
	} else {
		$selected_k = 0;
	}
	$content = file_get_contents($files[$selected_k]['path']);
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    

    <title></title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/application.css" rel="stylesheet">

	</head>
	<body>
	    <div class="container-fluid">
			<div class="row">
				<div class="col-sm-3 col-md-2 sidebar">
					<ul class="nav nav-sidebar">
	            		<?php foreach ($files as $k => $file):?>
							<li class="<?php if ((int) $k === (int) $selected_k): echo 'active'; endif;?>">
								<a href="index.php?k=<?php echo $k;?>"><i class="oc-partial-icon icm icm-file"></i><span class="oc-partial-menu-item"><?php echo $file['name'];?></span></a>    
							</li>
						<?php endforeach;?>
					</ul>
	        	</div>
				<div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
		          	<?php include $files[$selected_k]['include']; ?>
				</div> <!-- end of .main -->
			</div> <!-- end of .roe -->
		</div> <!-- end of .container-fluid -->
  
		<script src="js/jquery-1.11.1.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
	</body>  
</html>