<?php 
	error_reporting(0);
	define('sec', 1);
	require dirname(__FILE__).'/config.php';
	if (isset($_REQUEST['k'])) {
		$key = trim(strip_tags($_REQUEST['k']));
	} else {
		$selected_k = key($files);
	}
	if (!empty($key) && isset($files[$key])) {
		$selected_k = $key;
	} else {
		$selected_k = key($files);
	}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/application2.css" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

        <!-- Sidebar -->
        <div id="sidebar-wrapper">
            <ul class="sidebar-nav">
                <li class="<?php if ($selected_k === 'badusb'): echo 'active'; endif;?>">
								<a href="index.php?k=badusb"><i class="oc-partial-icon icm icm-file"></i><span class="oc-partial-menu-item">Bad USB Attack</span></a>    
						</li>
						<li class="<?php if ($selected_k === 'dnsmasq'): echo 'active'; endif;?>">
							<a href="index.php?k=dnsmasq"><i class="oc-partial-icon icm icm-file"></i><span class="oc-partial-menu-item">Dnsmasq Service</span></a>    
						</li>
						
						<li>
							<li class="<?php if ($selected_k === 'hid'): echo 'active'; endif;?>">
							<a href="index.php?k=hid"><i class="oc-partial-icon icm icm-file"></i><span class="oc-partial-menu-item">HID keyboard Attack</span></a>    
						</li>
						<li>
							<li class="<?php if ($selected_k === 'hostapd-config'): echo 'active'; endif;?>">
							<a href="index.php?k=hostapd-config"><i class="oc-partial-icon icm icm-file"></i><span class="oc-partial-menu-item">Hostapd config</span></a>    
						</li>
						<li class="<?php if ($selected_k === 'mana'): echo 'active'; endif;?>">
							<a href="index.php?k=mana"><i class="oc-partial-icon icm icm-file"></i><span class="oc-partial-menu-item">Mana Evil Access Point</span></a>    
						</li>
						<li class="<?php if ($selected_k === 'kaliservices'): echo 'active'; endif;?>">
							<a href="index.php?k=kaliservices"><i class="oc-partial-icon icm icm-file"></i><span class="oc-partial-menu-item">Kali services</span></a>    
						</li>
            </ul>
        </div>
        <!-- /#sidebar-wrapper -->

        <!-- Page Content -->
        <div id="page-content-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <p></p>
                        <a href="#menu-toggle" class="btn btn-primary btn-sm" id="menu-toggle">Toggle nav</a>
						<?php if (isset($files[$selected_k]['include']) && is_file($files[$selected_k]['include'])):?>
							<?php include $files[$selected_k]['include']; ?>  		
						<?php else: ?>
		          	
						<?php endif;?>            
                    </div>
                </div>
            </div>
        </div>
        <!-- /#page-content-wrapper -->

    </div>
    <!-- /#wrapper -->

    <script src="js/jquery-1.11.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/scripts.js"></script>


    <script>
    $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });
    </script>

</body>

</html>
