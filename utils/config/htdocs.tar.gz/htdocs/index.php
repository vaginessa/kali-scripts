<?php
	error_reporting(0);
	define('sec', 1);
	require dirname(__FILE__).'/config.php';
	if (isset($_REQUEST['k'])) {
		$key = trim(strip_tags($_REQUEST['k']));
	} else {
		$selected_k = 'home';
	}
	if (!empty($key) && isset($files[$key])) {
		$selected_k = $key;
	} else {
		$selected_k = 'home';
	}
	if (isset($_POST['ajax']) && isset($_POST['action'])) {
		$aaction = trim(strip_tags($_POST['action']));
		switch($aaction):
			case 'startmana':
				$o = shell_exec('start-mana &> /sdcard/htdocs/mana.log &');
				$res = array('status' => 100, 'message' => 'Mana started.');
				break;
			case 'stopmana':
				$o = shell_exec('stop-mana');
				$res = array('status' => 100, 'message' => 'Mana stopped.');
				break;
			case 'starthostapd':
				$o = shell_exec('start-hostapd');
				$res = array('status' => 100, 'message' => 'Hostapd started.');
				break;
			case 'stophostapd':
				$o = shell_exec('stop-hostapd');
				$res = array('status' => 100, 'message' => 'Hostapd stopped.');
				break;
			case 'startdnsmasq':
				$o = shell_exec('start-dnsmasq');
				$res = array('status' => 100, 'message' => 'Dnsmasq started.');
				break;
			case 'stopdnsmasq':
				$o = shell_exec('stop-dnsmasq');
				$res = array('status' => 100, 'message' => 'Dnsmasq stopped.');
				break;
			case 'startbadusb':
				$o = shell_exec('start-badusb');
				$res = array('status' => 100, 'message' => 'Attack started.');
				break;
			case 'stopbadusb':
				$o = shell_exec('stop-badusb');
				$res = array('status' => 100, 'message' => 'Attack stopped.');
				break;
			case 'startdhcp':
				$o = shell_exec('');
				$res = array('status' => 100, 'message' => 'DHCP service started.');
				break;
			case 'stopdhcp':
				$o = shell_exec('');
				$res = array('status' => 100, 'message' => 'DHCP service stopped.');
				break;
				
			default:
				$res = array('status' => 200, 'message' => 'Unrecognized action!');
				break;
		endswitch;
		echo json_encode($res);
		die;
	}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/application.css" rel="stylesheet">
</head>

<body>
<div id="wrapper">
	<div id="sidebar-wrapper">
            <ul class="sidebar-nav">
                <li class="<?php if ($selected_k === 'home'): echo 'active'; endif;?>">
					<a href="index.php?k=home"><i class="oc-partial-icon icm icm-file"></i><span class="oc-partial-menu-item">Nethunter Panel</span></a>    
				</li>
				<li class="<?php if ($selected_k === 'kaliservices'): echo 'active'; endif;?>">
					<a href="index.php?k=kaliservices"><i class="oc-partial-icon icm icm-file"></i><span class="oc-partial-menu-item">Kali Services Control</span></a>    
				</li>
				<li class="<?php if ($selected_k === 'dnsmasq'): echo 'active'; endif;?>">
					<a href="index.php?k=dnsmasq"><i class="oc-partial-icon icm icm-file"></i><span class="oc-partial-menu-item">Dnsmasq Service</span></a>    
				</li>
				<li class="<?php if ($selected_k === 'dhcpd'): echo 'active'; endif;?>">
					<a href="index.php?k=dhcpd"><i class="oc-partial-icon icm icm-file"></i><span class="oc-partial-menu-item">DHCP Service</span></a>    
				</li>
				<li>
				<li class="<?php if ($selected_k === 'hostapd-config'): echo 'active'; endif;?>">
					<a href="index.php?k=hostapd-config"><i class="oc-partial-icon icm icm-file"></i><span class="oc-partial-menu-item">Hostapd Service</span></a>    
				</li>
				<li class="<?php if ($selected_k === 'hid'): echo 'active'; endif;?>">
					<a href="index.php?k=hid"><i class="oc-partial-icon icm icm-file"></i><span class="oc-partial-menu-item">HID keyboard Attack</span></a>    
				</li>				
				<li class="<?php if ($selected_k === 'mana'): echo 'active'; endif;?>">
					<a href="index.php?k=mana"><i class="oc-partial-icon icm icm-file"></i><span class="oc-partial-menu-item">Mana Evil Access Point</span></a>    
				</li>
                <li class="<?php if ($selected_k === 'badusb'): echo 'active'; endif;?>">
					<a href="index.php?k=badusb"><i class="oc-partial-icon icm icm-file"></i><span class="oc-partial-menu-item">Bad USB Attack</span></a>    
				</li>
				
				<li>
            </ul>
	</div> <!-- /#sidebar-wrapper -->
    
	<!-- Page Content -->
	<div id="page-content-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <a href="#menu-toggle" class="btn btn-primary btn-sm" id="menu-toggle">Toggle nav</a>
						<?php if (isset($files[$selected_k]['include']) && is_file($files[$selected_k]['include'])):?>
							<?php include $files[$selected_k]['include']; ?>  		
						<?php else: ?>
						<?php endif;?>            
                    </div>
                </div>
            </div>
	</div> <!-- /#page-content-wrapper -->
</div> <!-- /#wrapper -->
    
    
    <script src="js/jquery-1.11.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/scripts.js"></script>

</body>

</html>
