jQuery(document).ready(function(){
			var url = document.location.toString();
			if (url.match('#')) {
			    $('.nav-tabs a[href=#'+url.split('#')[1]+']').tab('show') ;
			} 

			$('.nav-tabs a').on('shown', function (e) {
			    window.location.hash = e.target.hash;
			});
});


$(document).ready(function () {
	  $('[data-toggle=offcanvas]').click(function () {
	    if ($('.sidebar-offcanvas').css('background-color') == 'rgb(255, 255, 255)') {
		    $('.list-group-item').attr('tabindex', '-1');
	    } else {
		    $('.list-group-item').attr('tabindex', '');
	    }
	    $('.row-offcanvas').toggleClass('active');	    
	  });
	  
	  /*
	  var documentHeight = $(window).innerHeight();
	    jQuery('#sidebar').css('height',documentHeight);
	    */
});

function startStop(action)
{
	var data = 'action=' + action + '&ajax=1';
	var ajax_options = {
	        beforeSend:function () 
	        {
	            jQuery('#ajax-throbber').css('display', 'inline');
	        },
	        complete:function () 
	        {
	        	jQuery('#ajax-throbber').css('display', 'none');
	        },
	        error:function (XMLHttpRequest, textStatus, errorThrown) 
	        {
	            alert('There was an error durring request. Please try again later!');
	        },
	        success:function (response, textStatus) 
	        {
	        	$('#alert-modal .modal-body').html('<h3>' + response.message + '</h3>')
	        	$('#alert-modal').modal('show');
	        	return false;
	        },
	        timeout:'100000',
	        type:'POST',
	        dataType:'json',
	        data: data,
	        url:'index.php'
	    };
	$.ajax(ajax_options);
	return false;
}
