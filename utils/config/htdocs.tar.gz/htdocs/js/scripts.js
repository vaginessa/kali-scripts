jQuery(document).ready(function(){
			var url = document.location.toString();
			if (url.match('#')) {
			    $('.nav-tabs a[href=#'+url.split('#')[1]+']').tab('show') ;
			} 

			$('.nav-tabs a').on('shown', function (e) {
			    window.location.hash = e.target.hash;
			});
});


$(document).ready(function () {
	  $('[data-toggle=offcanvas]').click(function () {
	    if ($('.sidebar-offcanvas').css('background-color') == 'rgb(255, 255, 255)') {
		    $('.list-group-item').attr('tabindex', '-1');
	    } else {
		    $('.list-group-item').attr('tabindex', '');
	    }
	    $('.row-offcanvas').toggleClass('active');
	    
	  });
	  
	  var documentHeight = $(window).innerHeight();
	    jQuery('#sidebar').css('height',documentHeight);
	});
