jQuery(document).ready(function(){
			var url = document.location.toString();
			if (url.match('#')) {
			    $('.nav-tabs a[href=#'+url.split('#')[1]+']').tab('show') ;
			} 

			$('.nav-tabs a').on('shown', function (e) {
			    window.location.hash = e.target.hash;
			});
			
			$("#menu-toggle").click(function(e) {
		        e.preventDefault();
		        $("#wrapper").toggleClass("toggled");
		    });
});


$(document).ready(function () {
	  $('[data-toggle=offcanvas]').click(function () {
	    if ($('.sidebar-offcanvas').css('background-color') == 'rgb(255, 255, 255)') {
		    $('.list-group-item').attr('tabindex', '-1');
	    } else {
		    $('.list-group-item').attr('tabindex', '');
	    }
	    $('.row-offcanvas').toggleClass('active');	    
	  });
	  
	  if ($('#main-alert').length){
	    	window.setTimeout(function () {
      		$('#main-alert').slideUp();
      	}, 3000);
	    }
});

function startStop(action)
{
	var data = 'action=' + action + '&ajax=1';
	var ajax_options = {
	        beforeSend:function () 
	        {
	            jQuery('#ajax-throbber').css('display', 'inline');
	        },
	        complete:function () 
	        {
	        	jQuery('#ajax-throbber').css('display', 'none');
	        },
	        error:function (XMLHttpRequest, textStatus, errorThrown) 
	        {
	            alert('There was an error durring request. Please try again later!');
	        },
	        success:function (response, textStatus) 
	        {
	        	$('#ajax-messages p').text(response.message);
	        	$('#ajax-messages').fadeIn();
	        	
	        	window.setTimeout(function () {
	        		$('#ajax-messages').fadeOut('in');
	        	}, 3000);
	        	return false;
	        },
	        timeout:'100000',
	        type:'POST',
	        dataType:'json',
	        data: data,
	        url:'index.php'
	    };
	$.ajax(ajax_options);
	return false;
}

function StartStopKaliServices(action)
{ 
	var data = 'action=' + action + '&ajax=1';
	var ajax_options = {
	        beforeSend:function () 
	        {
	            jQuery('#ajax-throbber').css('display', 'inline');
	        },
	        complete:function () 
	        {
	        	jQuery('#ajax-throbber').css('display', 'none');
	        },
	        error:function (XMLHttpRequest, textStatus, errorThrown) 
	        {
	            alert('There was an error durring request. Please try again later!');
	        },
	        success:function (response, textStatus) 
	        {
	        	var res = action.replace(/start|stop/, '');
	        	var string = '<div class="alert alert-info" id="main-alert" style="margin:5px 0 0;" role="alert"><p>' + response.message + '</p></div>';
	        	jQuery('#' + res).append(string);
	        	window.setTimeout(function () {
	        		jQuery('#main-alert').remove();
	        	}, 3000);
	        	return false;
	        },
	        timeout:'100000',
	        type:'POST',
	        dataType:'json',
	        data: data,
	        url:'index.php'
	    };
	$.ajax(ajax_options);
	return false;
}
