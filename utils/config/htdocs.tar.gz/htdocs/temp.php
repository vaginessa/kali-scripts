 
$files['hostapd-config']                = array('path'          => dirname(__FILE__).'/files/hostapd-config',
												'include'       => dirname(__FILE__).'/includes/hostapd-config.php');

$files['hostapd-karma']                 = array('path'          => dirname(__FILE__).'/files/hostapd-config',



$files['hostapd-config']                = array('path'          => dirname(__FILE__).'/files/hostapd.conf',
                                                'include'       => dirname(__FILE__).'/includes/hostapd-config.php');

$files['hostapd-karma']                 = array('path'          => dirname(__FILE__).'/files/hostapd-karma.conf',
