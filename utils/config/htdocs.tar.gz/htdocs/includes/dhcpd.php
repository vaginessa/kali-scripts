<?php 
	if (isset($_POST['action']) && $_POST['action'] === 'updateSource'):
		$new_source = trim(strip_tags($_POST['source']));
		file_put_contents($files['dhcpd']['path'], $new_source);	
		$message = 'Source updated!';
	endif;
	$con = file_get_contents($files['dhcpd']['path']);
?>
<div class="tab-content no-border">
	<div class="well well-lg description">
		<h3>ISC DHCPD server configuration</h3>
		<p>ISC DHCP is open source software that implements the Dynamic Host Configuration Protocol for connection to an IP network.</p>
	</div>
	<?php require dirname(__FILE__).'/messages.php';?>
	<ul class="nav nav-tabs" role="tablist">
		<li class="active"><a href="#dhcpdsource" role="tab" data-toggle="tab">Source</a></li>  				
	</ul>
	<div class="tab-content">
		<div id="dhcpdsource" class="tab-pane fade in active">
			<form action="index.php#dhcpdsource" method="POST">
				<input type="hidden" name="k" value="dhcpd" />
				<input type="hidden" name="action" value="updateSource" />
				<div class="form-group">		
					<textarea name="source" id="input-source" class="form-control panel-body md-input" rows="20"><?php echo $con;?></textarea>
				</div>
				<input class="btn btn-primary btn-sm" type="submit" value="Update" name="commit">
			</form>
		</div>
	</div> <!-- end of .tab-content -->
	<div class="alert alert-info" role="alert" id="ajax-messages" style="display:none;">
		<p></p>
	</div>
	<div class="bottom-buttons-group">
		<a href="javascript:void(0);" onclick="return startStop('startdhcp');"><input class="btn btn-success btn-sm" type="button" value="Start DHCP" name="commit"></a>						
		<a href="javascript:void(0);" onclick="return startStop('stopdhcp');"><input class="btn btn-danger btn-sm" type="button" value="Stop DHCP" name="commit"></a>
	</div>
</div>
