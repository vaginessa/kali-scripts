<?php
	if (isset($_POST['action']) && $_POST['action'] == 'update'):
		$wlan0 = isset($_POST['wlan0'])	?	strip_tags(trim($_POST['wlan0']))	:	'';
		$wlan1 = isset($_POST['wlan1'])	?	strip_tags(trim($_POST['wlan1']))	:	'';
		$con = file_get_contents($files[$selected_k]['path']);
		if (!empty($wlan0) && !empty($wlan1)):
			$line1 = "iptables -t nat -A POSTROUTING -o ".$wlan1." -j MASQUERADE";
			$line2 = "iptables -A FORWARD -i ".$wlan0." -o ".$wlan1." -j ACCEPT";
			$con = preg_replace('/^iptables -t nat -A POSTROUTING(.*)$/m', $line1, $con);
			$con = preg_replace('/^iptables -A FORWARD(.*)$/m', $line2, $con);
			file_put_contents($files[$selected_k]['path'], $con);
			$message = 'Options updated!';
		endif;
	elseif (isset($_POST['action']) && $_POST['action'] === 'updateSource'):
		$new_source = trim(strip_tags($_POST['source']));
		file_put_contents($files[$selected_k]['path'], $new_source);
		$message = 'Source updated!';
	endif;
	$con = file_get_contents($files[$selected_k]['path']);
	preg_match('/^iptables -A FORWARD -i (.*) -o (.*) -j ACCEPT(.*)$/m', $con, $match);
	$wlan0 = $match[1];
	$wlan1 = $match[2];
?>
<div class="well well-lg description">
	<h3>Iptables setup config</h3>
	<p>Easily set up NAT or use iptables rules to route traffic.</p>
</div>
<?php require dirname(__FILE__).'/messages.php';?>
<ul class="nav nav-tabs" role="tablist">
	<li class="active"><a href="#options" role="tab" data-toggle="tab">Options</a></li>
	<li><a href="#source" role="tab" data-toggle="tab">Source</a></li>  				
</ul>
<div class="tab-content">
	<div id="options" class="tab-pane fade in active pane-padded">
		<form action="/index.php" method="POST">
			<input type="hidden" name="action" value="update" />
			<input type="hidden" name="k" value="<?php echo $selected_k;?>" />
			
				<div class="form-group">
					<label for="input-wlan0">Local interface (wlan0)</label>
					<input id="input-wlan0" class="form-control" type="text" name="wlan0" placeholder="<?php echo $wlan0;?>" value="<?php echo $wlan0;?>" />
				</div>
				<div class="form-group">
					<label for="input-wlan1">Upstream interface (wlan1)</label>
					<input id="input-wlan1" class="form-control" type="text" name="wlan1" placeholder="<?php echo $wlan1;?>" value="<?php echo $wlan1;?>" />
				</div>
			<input class="btn btn-primary btn-sm" type="submit" value="Update" name="commit">
		</form>
	</div>
	
	<div id="source" class="tab-pane fade in pane-padded">
		<form action="index.php#source" method="POST">
			<input type="hidden" name="k" value="<?php echo $selected_k;?>" />
			<input type="hidden" name="action" value="updateSource" />
			<div class="form-group">		
				<textarea name="source" id="input-source" class="form-control panel-body md-input" rows="15"><?php echo $con;?></textarea>
			</div>
			<input class="btn btn-primary btn-sm" type="submit" value="Update" name="commit">
		</form>
	</div>
</div> <!-- end of .tab-content -->
<div class="alert alert-info" role="alert" id="ajax-messages" style="display:none;">
	<p></p>
</div>
<div class="bottom-buttons-group">
	<a href="javascript:void(0);" onclick="return startStop('iptaction1');"><input class="btn btn-success btn-sm" type="button" value="Button 1" name="commit"></a>
	<a href="javascript:void(0);" onclick="return startStop('iptflush');"><input class="btn btn-success btn-sm" type="button" value="Flush" name="commit"></a>						
</div>
