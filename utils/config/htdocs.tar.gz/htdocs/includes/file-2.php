<?php
	if (isset($_POST['action']) && $_POST['action'] === 'updateSource'):
		$new_source = trim(strip_tags($_POST['source']));
		file_put_contents($files[$selected_k]['path'], $new_source);
	endif;
	$con = file_get_contents($files[$selected_k]['path']);
?>
<ul class="nav nav-tabs" role="tablist">
	<li class="active"><a href="#source" role="tab" data-toggle="tab">Source</a></li>  				
</ul>
<div class="tab-content">
	<div id="source" class="tab-pane fade in active">
		<form action="index.php" method="POST">
			<input type="hidden" name="k" value="<?php echo (int) $selected_k;?>" />
			<input type="hidden" name="action" value="updateSource" />
			<div class="form-group">		
				<textarea name="source" id="input-source" class="form-control panel-body md-input" rows="20"><?php echo $con;?></textarea>
			</div>
			<input class="btn btn-primary" type="submit" value="Update source" name="commit">
		</form>
	</div>
</div> <!-- end of .tab-content -->
<div class="well well-lg description">
	<h3>This is title</h3>
	<p>This is some explanation for this file</p>
</div>