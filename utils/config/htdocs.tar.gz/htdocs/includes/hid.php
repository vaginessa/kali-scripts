<?php
function ascii2hex($ascii) {
	$hex = '';
	for ($i = 0; $i < strlen($ascii); $i++) {
		$byte = strtoupper(dechex(ord($ascii{$i})));
		$byte = str_repeat('0', 2 - strlen($byte)).$byte;
		$hex.=$byte." ";
	}
	return $hex;
}

function hex2ascii($hex){
	$ascii='';
	$hex=str_replace(" ", "", $hex);
	for($i=0; $i<strlen($hex); $i=$i+2) {
		$ascii.=chr(hexdec(substr($hex, $i, 2)));
	}
	return($ascii);
}
?>
<div class="well well-lg description">
	<h3>HID Pre Programmed Keyboard Attack</h3>
	<p>This attack turns your OTG USB cable into a pre-programmed keyboard, able to type any given commands. Previously, only "Teensy" type devices were able to do this...but no longer!</p>
</div>
<?php 
if (isset($_REQUEST['tab']) && in_array($_REQUEST['tab'], array('rtcppayload', 'rmpayload', 'rmhttpspayload'))):
	$selected_tab = $_REQUEST['tab'];
else:
	$selected_tab = 'rtcppayload';
endif;
?>
<nav class="navbar navbar-default" role="navigation">
	<div class="container-fluid">
		<ul class="nav navbar-nav nav-tabs submenu" role="tablist">
			<li class="<?php if ($selected_tab == 'rtcppayload'): echo "active";endif; ?>"><a href="#rtcppayload" role="tab" data-toggle="tab">Reverse TCP</a></li>
			<li class="<?php if ($selected_tab == 'rmpayload'): echo "active";endif; ?>"><a href="#rmpayload" role="tab" data-toggle="tab">Reverse Meterpreter</a></li>
			<li class="<?php if ($selected_tab == 'rmhttpspayload'): echo "active";endif; ?>"><a href="#rmhttpspayload" role="tab" data-toggle="tab">Reverse Metrepreter HTTPS</a></li>
		</ul>
	</div><!-- /.container-fluid -->
</nav>

<div class="tab-content no-border">
	<div id="rtcppayload" class="tab-pane fade in<?php if ($selected_tab == 'rtcppayload'): echo " active";endif; ?>">
		<?php include $files['reversetcp']['include'];?>
	</div>
	<div id="rmpayload" class="tab-pane fade in<?php if ($selected_tab == 'rmpayload'): echo " active";endif; ?>">
		<?php include $files['reverse-meterpreter']['include'];?>
	</div>
	<div id="rmhttpspayload" class="tab-pane fade in<?php if ($selected_tab == 'rmhttpspayload'): echo " active";endif; ?>">
		<?php include $files['reverse-https']['include'];?>
	</div>
</div>
