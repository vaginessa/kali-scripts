<?php
function ascii2hex($ascii) {
	$hex = '';
	for ($i = 0; $i < strlen($ascii); $i++) {
		$byte = strtoupper(dechex(ord($ascii{$i})));
		$byte = str_repeat('0', 2 - strlen($byte)).$byte;
		$hex.=$byte." ";
	}
	return $hex;
}

function hex2ascii($hex){
	$ascii='';
	$hex=str_replace(" ", "", $hex);
	for($i=0; $i<strlen($hex); $i=$i+2) {
		$ascii.=chr(hexdec(substr($hex, $i, 2)));
	}
	return($ascii);
}
?>
<div class="well well-lg description">
	<h3>HID Pre Programmed Keyboard Attack</h3>
	<p>This attack turns your OTG USB cable into a pre-programmed keyboard, able to type any given commands. Previously, only "Teensy" type devices were able to do this...but no longer!</p>
</div>
<nav class="navbar navbar-default" role="navigation">
	<div class="container-fluid">
		<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
			<ul class="nav navbar-nav nav-tabs" role="tablist"">
				<li class="active"><a href="#rtcppayload" role="tab" data-toggle="tab">Reverse TCP Payload</a></li>
				<li><a href="#rmpayload" role="tab" data-toggle="tab">Reverse Meterpreter Payload</a></li>
				<li><a href="#rmhttpspayload" role="tab" data-toggle="tab">Reverse Metrepreter HTTPS Payload</a></li>
			</ul>
		</div><!-- /.navbar-collapse -->
	</div><!-- /.container-fluid -->
</nav>
<div class="tab-content">
	<div id="rtcppayload" class="tab-pane fade in active">
		<?php include $files['reversetcp']['include'];?>
	</div>
	<div id="rmpayload" class="tab-pane fade in">
		<?php include $files['reverse-meterpreter']['include'];?>
	</div>
	<div id="rmhttpspayload" class="tab-pane fade in">
		<?php include $files['reverse-https']['include'];?>
	</div>
</div>
