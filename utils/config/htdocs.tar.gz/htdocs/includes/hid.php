<?php
function ascii2hex($ascii) {
	$hex = '';
	for ($i = 0; $i < strlen($ascii); $i++) {
		$byte = strtoupper(dechex(ord($ascii{$i})));
		$byte = str_repeat('0', 2 - strlen($byte)).$byte;
		$hex.=$byte." ";
	}
	return $hex;
}

function hex2ascii($hex){
	$ascii='';
	$hex=str_replace(" ", "", $hex);
	for($i=0; $i<strlen($hex); $i=$i+2) {
		$ascii.=chr(hexdec(substr($hex, $i, 2)));
	}
	return($ascii);
}
?>
<div class="well well-lg description">
	<h3>HID Keyboard Attack</h3>
	<p>This attack turns your OTG USB cable into a pre-programmed keyboard, able to type any given commands. Previously, only "Teensy" type devices were able to do this...but no longer! <br />

<font color="red">Configuration:</font> Default config is pretty much "good to go", just configure commands, IPs or ports. The <b>Powersploit</b> <i>URL</i> option should point back to the Nexus device IP, or some other webserver hosting the powershell payload. If you choose to use the built in, automated Apache server on Nethunter, don't forget to <a href="index.php?k=kaliservices">start the Apache server</a> before you initiate the attack. If the "Execute attack becomes non-responsive, use the "<b>Reset USB</b>" button to freshen up the USB stack.</p>
</div>
<?php 
if (isset($_REQUEST['tab']) && in_array($_REQUEST['tab'], array('rtcppayload', 'rmpayload', 'rmhttpspayload'))):
	$selected_tab = $_REQUEST['tab'];
else:
	$selected_tab = 'rtcppayload';
endif;
?>
<nav class="navbar navbar-default" role="navigation">
	<div class="container-fluid">
		<ul class="nav navbar-nav nav-tabs no-border" role="tablist">
			<li class="<?php if ($selected_tab == 'rtcppayload'): echo "active";endif; ?>"><a href="#rtcppayload" role="tab" data-toggle="tab">Reverse TCP</a></li>
			<li class="<?php if ($selected_tab == 'rmpayload'): echo "active";endif; ?>"><a href="#powersploit" role="tab" data-toggle="tab">Powersploit</a></li>
			<li class="<?php if ($selected_tab == 'cmd'): echo "active";endif; ?>"><a href="#cmd" role="tab" data-toggle="tab">Windows CMD</a></li>
		</ul>
	</div><!-- /.container-fluid -->
</nav>

<div class="tab-content no-border">
	<div id="rtcppayload" class="tab-pane fade in<?php if ($selected_tab == 'rtcppayload'): echo " active";endif; ?>">
		<?php include $files['reversetcp']['include'];?>
	</div>
	<div id="powersploit" class="tab-pane fade in<?php if ($selected_tab == 'powersploit'): echo " active";endif; ?>">
		<?php include $files['powersploit']['include'];?>
	</div>
	<div id="cmd" class="tab-pane fade in<?php if ($selected_tab == 'cmd'): echo " active";endif; ?>">
		<?php include $files['hid-cmd']['include'];?>
	</div>
</div>