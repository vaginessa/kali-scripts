<div class="well well-lg description">
	<h3>"Mana" Evil Access Point Attack</h3>
	<p>This is the configuratoin page for "Mana", and evil accesspoint implementation by Sensepost. Configure the hostapd file, then tun the command "mana" from a Kali shell. Logs get written to <b>/captures/mana/</b> in the Kali chroot. </p>
</div>
<?php 
if (isset($_REQUEST['tab']) && in_array($_REQUEST['tab'], array('hostapd-karma', 'dhcpd', 'dnsspoof'))):
	$selected_tab = $_REQUEST['tab'];
else:
	$selected_tab = 'hostapd-karma';
endif;
?>
<nav class="navbar navbar-default" role="navigation">
	<div class="container-fluid">
		<ul class="nav navbar-nav nav-tabs submenu" role="tablist">
			<li class="<?php if ($selected_tab == 'hostapd-karma'): echo "active";endif; ?>"><a href="#hostapd-karma" role="tab" data-toggle="tab">hostapd-karma.conf</a></li>
			<li class="<?php if ($selected_tab == 'dhcpd'): echo "active";endif; ?>"><a href="#dhcpd" role="tab" data-toggle="tab">dhcpd.conf</a></li>
			<li class="<?php if ($selected_tab == 'dnsspoof'): echo "active";endif; ?>"><a href="#dnsspoof" role="tab" data-toggle="tab">dnsspoof.conf</a></li>
		</ul>
	</div><!-- /.container-fluid -->
</nav>

<div class="tab-content no-border">
	<div id="hostapd-karma" class="tab-pane fade in<?php if ($selected_tab == 'hostapd-karma'): echo " active";endif; ?>">
		<?php include $files['hostapd-karma']['include'];?>
	</div>
	<div id="dhcpd" class="tab-pane fade in<?php if ($selected_tab == 'dhcpd'): echo " active";endif; ?>">
		<?php include $files['dhcpd']['include'];?>
	</div>
	<div id="dnsspoof" class="tab-pane fade in<?php if ($selected_tab == 'dnsspoof'): echo " active";endif; ?>">
		<?php include $files['dnsspoof']['include'];?>
	</div>
</div>
