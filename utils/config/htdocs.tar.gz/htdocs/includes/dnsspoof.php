<?php 
	if (isset($_POST['action']) && $_POST['action'] === 'updateSource' && isset($_POST['tab']) && $_POST['tab'] == 'dnsspoof'):
		$new_source = trim(strip_tags($_POST['source']));
		file_put_contents($files['dnsspoof']['path'], $new_source);	
	endif;
	$con = file_get_contents($files['dnsspoof']['path']);
?>
<ul class="nav nav-tabs" role="tablist">
	<li class="active"><a href="#dnsspoofsource" role="tab" data-toggle="tab">Source</a></li>  				
</ul>
<div class="tab-content">
	<div id="dnsspoofsource" class="tab-pane fade in active">
		<form action="index.php#dnsspoofsource" method="POST">
			<input type="hidden" name="k" value="<?php echo $selected_k;?>" />
			<input type="hidden" name="tab" value="dnsspoof" />
			<input type="hidden" name="action" value="updateSource" />
			<div class="form-group">		
				<textarea name="source" id="input-source" class="form-control panel-body md-input" rows="20"><?php echo $con;?></textarea>
			</div>
			<input class="btn btn-primary" type="submit" value="Update" name="commit">
		</form>
	</div>
</div> <!-- end of .tab-content -->
