<?php
	$message = '';
	if (isset($_POST['action']) && $_POST['action'] === 'start'):
		$res = shell_exec('LANG=C chroot /data/local/kali-armhf/ /usr/bin/badusb');
		$message = 'Attack started';
	elseif (isset($_POST['action']) && $_POST['action'] === 'stop'):
		$res = shell_exec('LANG=C chroot /data/local/kali-armhf/ /usr/bin/badcleanup');
		$message = 'Attack stoped';
	endif;
?>
<div class="well well-lg description">
	<h3>The "Bad USB" MITM attack</h3>
	<p>This is the implementation of the "<a href="https://srlabs.de/badusb/" target="_blank">Bad USB</a>" attack as demonstrated at Black Hat USA, 2014. Enabling this USB mode will turn your OTG USB cable in a network interface. Connecting the USB cable to a PC will force all traffic from that PC (Windows or Linux) through the Nethunter device, where the traffic can be MITM'ed. To start this attack you need to:
<ol>
  <li>Start the Bad USB attack using the button below.</li>
  <li>Set required values for the <b>dnsmasq</b> service, set the interface to rndis0 or usb0*.</li>
  <li>Restart the dnsmasq service.</li>
  <li>Connect your OTG USB cable to a target PC.</li>
  <li>Once completed, stop the Bad USB attack to regain normal USB functionality.</li>

</ol>
</p>
</div>
<?php if (!empty($message)):?>
	
	<div class="alert alert-info" role="alert">
	<p><?php echo $message;?></p>
	</div>
	
<?php endif;?>
<form action="index.php" method="POST" class="pull-left">
	<input type="hidden" name="k" value="<?php echo $selected_k;?>" />
	<input type="hidden" name="action" value="start" />
	<input class="btn btn-primary" type="submit" value="Start BadUSB Attack" name="commit">
</form>
<form action="index.php" method="POST" class="pull-left" style="margin-left:20px;">
	<input type="hidden" name="k" value="<?php echo $selected_k;?>" />
	<input type="hidden" name="action" value="stop" />
	<input class="btn btn-danger" type="submit" value="Stop BadUSB Attack" name="commit">
</form>
