<div class="well well-lg description">
	<h3>The "Bad USB" MITM attack</h3>
	<p>This is the implementation of the "<a href="https://srlabs.de/badusb/" target="_blank">Bad USB</a>" attack as demonstrated at Black Hat USA, 2014. Enabling this USB mode will turn your OTG USB cable in a network interface. Connecting the USB cable to a PC will force all traffic from that PC (Windows or Linux) through the Nethunter device, where the traffic can be MITM'ed. To start this attack you need to:</p>
	<ol>
		<li>Start the Bad USB attack using the button below.</li>
		<li>Set required values for the <b>dnsmasq</b> service, set the interface to rndis0 or usb0*.</li>
		<li>Restart the dnsmasq service.</li>
		<li>Connect your OTG USB cable to a target PC.</li>
		<li>Once completed, stop the Bad USB attack to regain normal USB functionality.</li>
	</ol>
</div>

<div class="alert alert-info" role="alert" id="ajax-messages" style="display:none;">
	<p></p>
</div>
<div class="bottom-buttons-group">
	<a href="javascript:void(0);" onclick="return startStop('startbadusb');"><input class="btn btn-success btn-sm" type="button" value="Start BadUSB Attack" name="commit"></a>						
	<a href="javascript:void(0);" onclick="return startStop('stopbadusb');"><input class="btn btn-danger btn-sm" type="button" value="Stop BadUSB Attack" name="commit"></a>
</div>
