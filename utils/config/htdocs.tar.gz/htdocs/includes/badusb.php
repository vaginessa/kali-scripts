<?php
	$message = '';
	if (isset($_POST['action']) && $_POST['action'] === 'start'):
		//$res = shell_exec('badusb-start');
		$message = 'Attack started';
	elseif (isset($_POST['action']) && $_POST['action'] === 'stop'):
		//$res = shell_exec('badusb-stop');
		$message = 'Attack stoped';
	endif;
?>
<div class="well well-lg description">
	<h3>This is title</h3>
	<p>This is some explanation for this file</p>
</div>
<?php if (!empty($message)):?>
	
	<div class="alert alert-info" role="alert">
	<p><?php echo $message;?></p>
	</div>
	
<?php endif;?>
<form action="index.php" method="POST" class="pull-left">
	<input type="hidden" name="k" value="<?php echo $selected_k;?>" />
	<input type="hidden" name="action" value="start" />
	<input class="btn btn-primary" type="submit" value="Start BadUSB Attack" name="commit">
</form>
<form action="index.php" method="POST" class="pull-left" style="margin-left:20px;">
	<input type="hidden" name="k" value="<?php echo $selected_k;?>" />
	<input type="hidden" name="action" value="stop" />
	<input class="btn btn-danger" type="submit" value="Stop BadUSB Attack" name="commit">
</form>