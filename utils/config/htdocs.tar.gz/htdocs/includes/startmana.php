<?php 
	
	if (isset($_POST['action']) && $_POST['action'] == 'update' && isset($_POST['tab']) && $_POST['tab'] == 'startmana'):		
		$upstream	= isset($_POST['upstream'])	?	trim(strip_tags($_POST['upstream']))	:	'';
		$phy		= isset($_POST['phy'])	?	trim(strip_tags($_POST['phy']))	:	'';	
		if (!empty($upstream) && !empty($phy)):
			$con = file_get_contents($files['startmana']['path']);
			$con = preg_replace('/^upstream=(.*)$/m', 'upstream='.$upstream, $con);
			$con = preg_replace('/^phy=(.*)$/m', 'phy='.$phy, $con);
			file_put_contents($files['startmana']['path'], $con);
			$message = 'Options updated!';
		else:
			$message = 'Input invalid!';
		endif;
	elseif (isset($_POST['action']) && $_POST['action'] === 'updateSource' && isset($_POST['tab']) && $_POST['tab'] == 'startmana'):
		$new_source = trim(strip_tags($_POST['source']));
		file_put_contents($files['startmana']['path'], $new_source);
		$message = 'Source updated!';
	endif;
	$con = file_get_contents($files['startmana']['path']);
	preg_match( '/^upstream=(.*)$/m', $con, $tmp);
	preg_match( '/^phy=(.*)$/m', $con, $tmp1);
	$upstream	= $tmp[1];
	$phy		= $tmp1[1];
?>
<?php require dirname(__FILE__).'/messages.php';?>
<ul class="nav nav-tabs" role="tablist">
	<li class="active"><a href="#startmanaoptions" role="tab" data-toggle="tab">Options</a></li>
	<li class=""><a href="#startmanasource" role="tab" data-toggle="tab">Source</a></li>  				
</ul>
<div class="tab-content">
	<div id="startmanaoptions" class="tab-pane fade in active">
		<form action="index.php#startmanaoptions" method="POST">
			<input type="hidden" name="action" value="update" />
			<input type="hidden" name="tab" value="startmana" />
			<input type="hidden" name="k" value="mana" />
			<div class="form-group">
				<label for="input-upstream">upstream</label>
				<input id="input-upstream" class="form-control" type="text" name="upstream" placeholder="<?php echo $upstream;?>" value="<?php echo $upstream;?>" />
			</div>
			<div class="form-group">
				<label for="input-phy">Phy</label>
				<input id="input-phy" class="form-control" type="text" name="phy" placeholder="<?php echo $phy;?>" value="<?php echo $phy;?>" />
			</div>
				
			
			<input class="btn btn-primary btn-sm" type="submit" value="Update" name="commit">
		</form>
	</div>
	<div id="startmanasource" class="tab-pane fade in">
		<form action="index.php#startmanasource" method="POST">
			<input type="hidden" name="k" value="mana" />
			<input type="hidden" name="tab" value="startmana" />
			<input type="hidden" name="action" value="updateSource" />
			<div class="form-group">		
				<textarea name="source" id="input-source" class="form-control panel-body md-input" rows="20"><?php echo $con;?></textarea>
			</div>
			<input class="btn btn-primary btn-sm" type="submit" value="Update" name="commit">
		</form>
	</div>
</div> <!-- end of .tab-content -->