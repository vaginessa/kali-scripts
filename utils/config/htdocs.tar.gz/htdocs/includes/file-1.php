<?php 
	$values = array('address', 'port');
	if (isset($_POST['action']) && $_POST['action'] == 'update'):
		$con = file_get_contents($files[$selected_k]['path']);
		foreach ($values as $v):
			if (isset($_POST[$v])):
				$new_value = '$'.$v.' = \''.strip_tags(trim($_POST[$v]))."'";
				$con = preg_replace('/\$'.$v.' = \'([0-9\.]*)\'/', $new_value, $con);
			endif;
		endforeach;		
		file_put_contents($files[$selected_k]['path'], $con);
	elseif (isset($_POST['action']) && $_POST['action'] === 'updateSource'):
		$new_source = trim(strip_tags($_POST['source']));
		file_put_contents($files[$selected_k]['path'], $new_source);
	endif;
	$con = file_get_contents($files[$selected_k]['path']);
	foreach ($values as $v):
		$match = array();
		preg_match('/\$'.$v.' = \'([0-9\.]*)\'/', $con, $match );
		if (isset($match[1])):
			$$v = $match[1];
		else:
			$$v = '';
		endif;
	endforeach;
	
?>
<ul class="nav nav-tabs" role="tablist">
  				<li class="active"><a href="#options" role="tab" data-toggle="tab">Options</a></li>
				<li class=""><a href="#source" role="tab" data-toggle="tab">Source</a></li>  				
</ul>
<div class="tab-content">
				<div id="options" class="tab-pane fade in active">
					<form action="/index.php" method="POST">
	<input type="hidden" name="action" value="update" />
	<input type="hidden" name="k" value="<?php echo (int) $selected_k;?>" />
	<?php foreach ($values as $v):?>
		<div class="form-group">
			<label for="input-<?php echo $v;?>"><?php echo $v;?></label>
			<input id="input-<?php echo $v;?>" class="form-control" type="text" name="<?php echo $v;?>" placeholder="<?php echo $v;?>" value="<?php echo $$v;?>" />
		</div>
	<?php endforeach;?>
	<input class="btn btn-primary" type="submit" value="Update options" name="commit">
</form>
	</div>
	<div id="source" class="tab-pane fade in">
		<form action="index.php" method="POST">
			<input type="hidden" name="k" value="<?php echo (int) $selected_k;?>" />
			<input type="hidden" name="action" value="updateSource" />
			<div class="form-group">		
				<textarea name="source" id="input-source" class="form-control panel-body md-input" rows="20"><?php echo $con;?></textarea>
			</div>
			<input class="btn btn-primary" type="submit" value="Update source" name="commit">
		</form>
	</div>
</div> <!-- end of .tab-content -->