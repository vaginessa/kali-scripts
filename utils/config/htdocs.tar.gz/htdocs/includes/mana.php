<?php 
	$values = array('interface', 'bssid', 'ssid', 'channel', 'enable_karma', 'karma_loud');
	if (isset($_POST['action']) && $_POST['action'] == 'update' && isset($_POST['tab']) && $_POST['tab'] == 'hostapd-karma'):		
		$con = file_get_contents($files['hostapd-karma']['path']);
		foreach ($values as $v):
			if (isset($_POST[$v])):
				$new_value = $v.'='.strip_tags(trim($_POST[$v]))."\n";
				$con = preg_replace('/^'.$v.'=(.*)$/m', $new_value, $con);
			endif;
		endforeach;
		file_put_contents($files['hostapd-karma']['path'], $con);
	elseif (isset($_POST['action']) && $_POST['action'] === 'updateSource' && isset($_POST['tab']) && $_POST['tab'] == 'hostapd-karma'):
		$new_source = trim(strip_tags($_POST['source']));
		file_put_contents($files['hostapd-karma']['path'], $new_source);
	elseif (isset($_GET['action']) && $_GET['action'] === 'start' && isset($_GET['tab']) && $_GET['tab'] == 'hostapd-karma'):
		$res = shell_exec('start-mana');
		$message = 'Mana started!';
	elseif (isset($_GET['action']) && $_GET['action'] === 'stop' && isset($_GET['tab']) && $_GET['tab'] == 'hostapd-karma'):
		$res = shell_exec('stop-mana');
		$message = 'Mana stopped!';
	endif;
	$con = file_get_contents($files['hostapd-karma']['path']);
	foreach ($values as $v):
		preg_match( '/^'.$v.'=(.*)$/m', $con, $match );
		if (isset($match[1])):
			$$v = $match[1];
		else:
			$$v = '';
		endif;
	endforeach;
?>
<?php if (!empty($message)):?>
	<div class="alert alert-info" role="alert">
		<p><?php echo $message;?></p>
	</div>
<?php endif;?>
<ul class="nav nav-tabs" role="tablist">
	<li class="active"><a href="#hostapdoptions" role="tab" data-toggle="tab">Options</a></li>
	<li class=""><a href="#hostapdsource" role="tab" data-toggle="tab">Source</a></li>  				
</ul>
<div class="tab-content">
	<div id="hostapdoptions" class="tab-pane fade in active">
					<form action="/index.php" method="POST">
						<input type="hidden" name="action" value="update" />
						<input type="hidden" name="tab" value="hostapd-karma" />
						<input type="hidden" name="k" value="<?php echo $selected_k;?>" />
			<?php foreach ($values as $v):?>
				<div class="form-group">
					<label for="input-<?php echo $v;?>"><?php echo $v;?></label>
					<input id="input-<?php echo $v;?>" class="form-control" type="text" name="<?php echo $v;?>" placeholder="<?php echo $v;?>" value="<?php echo $$v;?>" />
				</div>
			<?php endforeach;?>
			<input class="btn btn-primary btn-sm" type="submit" value="Update" name="commit">
			<a href="index.php?k=<?php echo $selected_k;?>&tab=hostapd-karma&action=start"><input class="btn btn-success btn-sm" type="button" value="Start mana" name="commit"></a>						
			<a href="index.php?k=<?php echo $selected_k;?>&tab=hostapd-karma&action=stop"><input class="btn btn-danger btn-sm" type="button" value="Stop mana" name="commit"></a>
		</form>
	</div>
	<div id="hostapdsource" class="tab-pane fade in">
		<form action="index.php#hostapdsource" method="POST">
			<input type="hidden" name="k" value="<?php echo $selected_k;?>" />
			<input type="hidden" name="tab" value="hostapd-karma" />
			<input type="hidden" name="action" value="updateSource" />
			<div class="form-group">		
				<textarea name="source" id="input-source" class="form-control panel-body md-input" rows="20"><?php echo $con;?></textarea>
			</div>
			<input class="btn btn-primary btn-sm" type="submit" value="Update" name="commit">
		</form>
	</div>
</div> <!-- end of .tab-content -->
