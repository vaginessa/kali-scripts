<div class="well well-lg description">
	<h3>"Mana" Evil Access Point</h3>
	<p>This is the configuration page for "Mana", an evil access-point implementation by Sensepost. MITM logs get written to <b>/captures/mana/</b> in the Kali chroot.<br />

<font color="red">Configuration:</font> Default config is pretty much "good to go". In the <b>mana-nat-full.sh</b> tab you can choose whether your <i>upstream</i> is your Nexus wifi (wlan0) or 3g (rmnet0).

 </p>
</div>
<?php
if (isset($_REQUEST['tab']) && in_array($_REQUEST['tab'], array('hostapd-karma', 'dhcpd', 'dnsspoof', 'startmana'))):
	$selected_tab = $_REQUEST['tab'];
else:
	$selected_tab = 'hostapd-karma';
endif;
?>
<nav class="navbar navbar-default" role="navigation">
	<div class="container-fluid">
		<ul class="nav navbar-nav nav-tabs no-border" role="tablist">
			<li class="<?php if ($selected_tab == 'hostapd-karma'): echo "active";endif; ?>"><a href="#hostapd-karma" role="tab" data-toggle="tab">hostapd-karma.conf</a></li>
			<li class="<?php if ($selected_tab == 'dhcpd-mana'): echo "active";endif; ?>"><a href="#dhcpd" role="tab" data-toggle="tab">dhcpd.conf</a></li>
			<li class="<?php if ($selected_tab == 'dnsspoof'): echo "active";endif; ?>"><a href="#dnsspoof" role="tab" data-toggle="tab">dnsspoof.conf</a></li>
			<li class="<?php if ($selected_tab == 'startmana'): echo "active";endif; ?>"><a href="#startmana" role="tab" data-toggle="tab">mana-nat-full.sh</a></li>
		</ul>
	</div><!-- /.container-fluid -->
</nav>

<div class="tab-content no-border">
	<div id="hostapd-karma" class="tab-pane fade in<?php if ($selected_tab == 'hostapd-karma'): echo " active";endif; ?>">
		<?php include $files['hostapd-karma']['include'];?>
	</div>
	<div id="dhcpd" class="tab-pane fade in<?php if ($selected_tab == 'dhcpd'): echo " active";endif; ?>">
		<?php include $files['dhcpd-mana']['include'];?>
	</div>
	<div id="dnsspoof" class="tab-pane fade in<?php if ($selected_tab == 'dnsspoof'): echo " active";endif; ?>">
		<?php include $files['dnsspoof']['include'];?>
	</div>
	<div id="startmana" class="tab-pane fade in<?php if ($selected_tab == 'startmana'): echo " active";endif; ?>">
		<?php include $files['startmana']['include'];?>
	</div>
</div>

<div class="alert alert-info" role="alert" id="ajax-messages" style="display:none;">
	<p></p>
</div>

<div class="bottom-buttons-group">
	<a href="javascript:void(0);" onclick="return startStop('startmana');"><input class="btn btn-success btn-sm" type="button" value="Start mana" name="commit"></a>						
	<a href="javascript:void(0);" onclick="return startStop('stopmana');"><input class="btn btn-danger btn-sm" type="button" value="Stop mana" name="commit"></a>
</div>
