<?php 
	if (isset($_POST['action']) && $_POST['action'] === 'updateSource' && isset($_POST['tab']) && $_POST['tab'] == 'cmd'):
		$new_source = trim(strip_tags($_POST['source']));
		file_put_contents($files['hid-cmd']['path'], $new_source);	
		$message = 'Source updated!';
	elseif (isset($_GET['action']) && $_GET['action'] === 'execute' && isset($_GET['tab']) && $_GET['tab'] == 'cmd'):
		$res = shell_exec('');
		$message = 'Attack executed!';
	endif;
	$con = file_get_contents($files['hid-cmd']['path']);
?>
<?php require dirname(__FILE__).'/messages.php';?>
<ul class="nav nav-tabs" role="tablist">
	<li class="active"><a href="#cmdsource" role="tab" data-toggle="tab">Source</a></li>  				
</ul>
<div class="tab-content">
	<div id="cmdsource" class="tab-pane fade in active">
		<form action="index.php#cmd" method="POST">
			<input type="hidden" name="k" value="hid" />
			<input type="hidden" name="tab" value="cmd" />
			<input type="hidden" name="action" value="updateSource" />
			<div class="form-group">		
				<textarea name="source" id="input-source" class="form-control panel-body md-input" rows="20"><?php echo $con;?></textarea>
			</div>
			<input class="btn btn-primary btn-sm" type="submit" value="Update" name="commit">
		</form>
	</div>
</div> <!-- end of .tab-content -->
<div class="alert alert-info ajax-messages" role="alert" id="ajax-messages-cmd" style="display:none;">
	<p></p>
</div>
<div class="bottom-buttons-group">
	<a href="index.php?k=hid&action=execute&tab=cmd#cmd"><input class="btn btn-success btn-sm" type="button" value="Execute Attack" name="commit"></a>
	<a href="javascript:void(0);" onclick="return startStop('resetusb', 'ajax-messages-cmd');"><input class="btn btn-warning btn-sm" type="button" value="Reset USB" name="commit"></a>
</div>
