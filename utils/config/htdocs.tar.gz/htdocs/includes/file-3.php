<?php
$values = array('rhost', 'rport');
if (isset($_POST['action']) && $_POST['action'] == 'update'):
	$con = file_get_contents($files[$selected_k]['path']);
	foreach ($values as $k => $v):
		if (isset($_POST[$v])):
			if ((int)$k === 0):
				$new_ip = strip_tags(trim($_POST[$v]));
				if (filter_var($new_ip, FILTER_VALIDATE_IP)):
					$tmp = explode('.', $new_ip);
					$new_value = '$'.$v."=";
					foreach ($tmp as $m => $p):
						$new_value .= "0x".dechex($p);
						if ((int) $m < (count($tmp)-1)):
							$new_value .= ",";
						else:
							$new_value .= ";";
						endif;
					endforeach;
					$con = preg_replace('/\$'.$v.'=(.*)$/m', $new_value, $con);
				endif;
			elseif ((int) $k === 1):
				$new_port = (int) $_POST[$v];
				if ($new_port >= 0 && $new_port <= 65535):
					$new_hex = dechex($new_port);
					$splited = str_split($new_hex, 2);
					$new_value = '$'.$v."=";
					foreach ($splited as $s => $pl):
						$new_value .= '0x'.$pl;
						if ((int) $s < (count($splited)-1)):
							$new_value .= ",";
						else:
							$new_value .= ";";
						endif;
					endforeach;
					$con = preg_replace('/\$'.$v.'=(.*)$/m', $new_value, $con);
				endif;
			endif;
		endif;
	endforeach;
	file_put_contents($files[$selected_k]['path'], $con);
elseif (isset($_POST['action']) && $_POST['action'] === 'updateSource'):
	$new_source = trim(strip_tags($_POST['source']));
	file_put_contents($files[$selected_k]['path'], $new_source);
endif;
$con = file_get_contents($files[$selected_k]['path']);
foreach ($values as $v):
	preg_match( '/\$'.$v.'=(.*)$/m', $con, $match );
	if (isset($match[1])):
		$$v = $match[1];
	else:
		$$v = '';
	endif;
endforeach;
?>
<ul class="nav nav-tabs" role="tablist">
	<li class="active"><a href="#options" role="tab" data-toggle="tab">Options</a></li>
	<li class=""><a href="#source" role="tab" data-toggle="tab">Source</a></li>  				
</ul>
<div class="tab-content">
	<div id="options" class="tab-pane fade in active">
		<form action="/index.php" method="POST">
			<input type="hidden" name="action" value="update" />
			<input type="hidden" name="k" value="<?php echo (int) $selected_k;?>" />
			<?php foreach ($values as $k => $v):?>
				<?php if ((int) $k === 0):?>
					<?php 
					$tmp = explode(",", trim($$v, ';'));
					$ip = '';
					foreach ($tmp as $y => $i):
						$ip .= hexdec(trim($i));
						$ip .=".";
					endforeach;
					$$v = trim($ip, '.');
					?>
				<?php else: ?>
					<?php 
					$tmp = explode(",", trim($$v, ';'));
					$hex ='';
					foreach ($tmp as $y => $i):
						$hex.=str_replace("0x", '', $i);
					endforeach;
					$$v = hexdec($hex);
					?>
				<?php endif; ?>
				<div class="form-group">
					<label for="input-<?php echo $v;?>"><?php if ((int) $k === 0): echo "address"; elseif((int) $k===1): echo "port"; else: echo $v; endif;?></label>
					<input id="input-<?php echo $v;?>" class="form-control" type="text" name="<?php echo $v;?>" placeholder="<?php echo $v;?>" value="<?php echo $$v;?>" />
				</div>
			<?php endforeach;?>
			<input class="btn btn-primary" type="submit" value="Update options" name="commit">
		</form>
	</div>
	<div id="source" class="tab-pane fade in">
		<form action="index.php" method="POST">
			<input type="hidden" name="k" value="<?php echo (int) $selected_k;?>" />
			<input type="hidden" name="action" value="updateSource" />
			<div class="form-group">		
				<textarea name="source" id="input-source" class="form-control panel-body md-input" rows="20"><?php echo $con;?></textarea>
			</div>
			<input class="btn btn-primary" type="submit" value="Update source" name="commit">
		</form>
	</div>
</div> <!-- end of .tab-content -->
					<div class="well well-lg description">
	<h3>This is title</h3>
	<p>This is some explanation for this file</p>
</div>