<?php
	$message = '';
	$action = isset($_GET['action'])	?	trim(strip_tags($_GET['action']))	:	'';
	if (!empty($action)):
		switch ($action):
			case 'startkalissh';
				$res = shell_exec('start-ssh');
				$message = 'Kali ssh started.';
				break;
			case 'stopkalissh';
				$res = shell_exec('stop-ssh');
				$message = 'Kali ssh stopped.';
				break;
			case 'startkalidnsmasq';
				$res = shell_exec('start-dnsmasq');
				$message = 'Kali dnsmasq started.';
				break;
			case 'stopkalidnsmasq';
				$res = shell_exec('stop-dnsmasq');
				$message = 'Kali dnsmasq stopped.';
				break;
			case 'startkalihostapd';
				$res = shell_exec('start-hostap');
				$message = 'Kali Hostapd started.';
				break;
			case 'stopkalihostapd';
				$res = shell_exec('stop-hostap');
				$message = 'Kali Hostapd stopped.';
				break;
			case 'startandroidweb';
				$res = shell_exec('start-web');
				$message = 'Android Web started.';
				break;
			case 'stopandroidweb';
				$res = shell_exec('stop-web');
				$message = 'Android Web stopped.';
				break;
			case 'startkalivpn';
				$res = shell_exec('start-vpn');
			$message = 'Kali VPN started.';
				break;
			case 'stopkalivpn';
				$res = shell_exec('stop-vpn');
				$message = 'Kali VPN stopped.';
				break;
			case 'startdhcp';
				$res = shell_exec('start-dhcp');
				$message = 'DHCP started.';
				break;
			case 'stopdhcp';
				$res = shell_exec('stop-dhcp');
				$message = 'DHCP stopped.';
				break;
		endswitch;	
	endif;
?>
<div class="well well-lg description">
	<h3>Kali services</h3>
	<p>Various Kali services you can stop and start via the web interface.</p>
</div>
<?php require dirname(__FILE__).'/messages.php';?>
<p class="kaliservices">
	<a href="index.php?k=<?php echo $selected_k;?>&action=startkalissh"><input class="btn btn-success btn-sm" type="button" value="Start Kali SSH" name="commit"></a>						
	<a href="index.php?k=<?php echo $selected_k;?>&action=stopkalissh"><input class="btn btn-danger btn-sm" type="button" value="Stop Kali SSH" name="commit"></a>
</p>
<p class="kaliservices">
	<a href="index.php?k=<?php echo $selected_k;?>&action=startkalidnsmasq"><input class="btn btn-success btn-sm" type="button" value="Start Kali dnsmasq" name="commit"></a>						
	<a href="index.php?k=<?php echo $selected_k;?>&action=stopkalidnsmasq"><input class="btn btn-danger btn-sm" type="button" value="Stop Kali dnsmasq" name="commit"></a>
</p>
<p class="kaliservices">
	<a href="index.php?k=<?php echo $selected_k;?>&action=startkalihostapd"><input class="btn btn-success btn-sm" type="button" value="Start Kali Hostapd" name="commit"></a>						
	<a href="index.php?k=<?php echo $selected_k;?>&action=stopkalihostapd"><input class="btn btn-danger btn-sm" type="button" value="Stop Kali Hostapd" name="commit"></a>
</p>
<p class="kaliservices">
	<a href="index.php?k=<?php echo $selected_k;?>&action=startandroidweb"><input class="btn btn-success btn-sm" type="button" value="Start Android Web" name="commit"></a>						
	<a href="index.php?k=<?php echo $selected_k;?>&action=stopandroidweb"><input class="btn btn-danger btn-sm" type="button" value="Stop Android Web" name="commit"></a>
</p>
<p class="kaliservices">
	<a href="index.php?k=<?php echo $selected_k;?>&action=startkalivpn"><input class="btn btn-success btn-sm" type="button" value="Start Kali VPN" name="commit"></a>						
	<a href="index.php?k=<?php echo $selected_k;?>&action=stopkalivpn"><input class="btn btn-danger btn-sm" type="button" value="Stop Kali VPN" name="commit"></a>
</p>
<p class="kaliservices">
	<a href="index.php?k=<?php echo $selected_k;?>&action=startdhcp"><input class="btn btn-success btn-sm" type="button" value="Start dhcp" name="commit"></a>						
	<a href="index.php?k=<?php echo $selected_k;?>&action=stopdhcp"><input class="btn btn-danger btn-sm" type="button" value="Stop dhcp" name="commit"></a>
</p>
