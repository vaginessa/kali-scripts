<?php
	$message = '';
	$action = isset($_GET['action'])	?	trim(strip_tags($_GET['action']))	:	'';
	if (!empty($action)):
		switch ($action):
			case 'startkalissh';
				#$res = shell_exec('FILL WITH APPROPRIATE COMMAND AND REMOVE COMMENT');
				$message = 'Kali ssh started!';
				break;
			case 'stopkalissh';
				#$res = shell_exec('FILL WITH APPROPRIATE COMMAND AND REMOVE COMMENT');
				$message = 'Kali ssh stopped!';
				break;
			case 'startkalidnsmasq';
				#$res = shell_exec('FILL WITH APPROPRIATE COMMAND AND REMOVE COMMENT');
				$message = 'Kali dnsmasq started!';
				break;
			case 'stopkalidnsmasq';
				#$res = shell_exec('FILL WITH APPROPRIATE COMMAND AND REMOVE COMMENT');
				$message = 'Kali dnsmasq stopped!';
				break;
			case 'startkalihostapd';
				#$res = shell_exec('FILL WITH APPROPRIATE COMMAND AND REMOVE COMMENT');
				$message = 'Kali Hostapd started!';
				break;
			case 'stopkalihostapd';
				#$res = shell_exec('FILL WITH APPROPRIATE COMMAND AND REMOVE COMMENT');
				$message = 'Kali Hostapd stopped!';
				break;
			case 'startandroidweb';
				#$res = shell_exec('FILL WITH APPROPRIATE COMMAND AND REMOVE COMMENT');
				$message = 'Android Web started!';
				break;
			case 'stopandroidweb';
				#$res = shell_exec('FILL WITH APPROPRIATE COMMAND AND REMOVE COMMENT');
				$message = 'Android Web stopped!';
				break;
			case 'startkalivpn';
				#$res = shell_exec('FILL WITH APPROPRIATE COMMAND AND REMOVE COMMENT');
			$message = 'Kali VPN started!';
				break;
			case 'stopkalivpn';
				#$res = shell_exec('FILL WITH APPROPRIATE COMMAND AND REMOVE COMMENT');
				$message = 'Kali VPN stopped!';
				break;
		endswitch;	
	endif;
?>
<div class="well well-lg description">
	<h3>Kali services</h3>
	<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium.</p>
</div>
<?php if (!empty($message)):?>
	<div class="alert alert-info" role="alert">
		<p><?php echo $message;?></p>
	</div>
<?php endif;?>
<p>
	<a href="index.php?k=<?php echo $selected_k;?>&action=startkalissh"><input class="btn btn-success kaliservices-button" type="button" value="Start Kali SSH" name="commit"></a>						
	<a href="index.php?k=<?php echo $selected_k;?>&action=stopkalissh"><input class="btn btn-danger kaliservices-button" type="button" value="Stop Kali SSH" name="commit"></a>
</p>
<p>
	<a href="index.php?k=<?php echo $selected_k;?>&action=startkalidnsmasq"><input class="btn btn-success kaliservices-button" type="button" value="Start Kali dnsmasq" name="commit"></a>						
	<a href="index.php?k=<?php echo $selected_k;?>&action=stopkalidnsmasq"><input class="btn btn-danger kaliservices-button" type="button" value="Stop Kali dnsmasq" name="commit"></a>
</p>
<p>
	<a href="index.php?k=<?php echo $selected_k;?>&action=startkalihostapd"><input class="btn btn-success kaliservices-button" type="button" value="Start Kali Hostapd" name="commit"></a>						
	<a href="index.php?k=<?php echo $selected_k;?>&action=stopkalihostapd"><input class="btn btn-danger kaliservices-button" type="button" value="Stop Kali Hostapd" name="commit"></a>
</p>
<p>
	<a href="index.php?k=<?php echo $selected_k;?>&action=startandroidweb"><input class="btn btn-success kaliservices-button" type="button" value="Start Android Web" name="commit"></a>						
	<a href="index.php?k=<?php echo $selected_k;?>&action=stopandroidweb"><input class="btn btn-danger kaliservices-button" type="button" value="Stop Android Web" name="commit"></a>
</p>
<p>
	<a href="index.php?k=<?php echo $selected_k;?>&action=startkalivpn"><input class="btn btn-success kaliservices-button" type="button" value="Start Kali VPN" name="commit"></a>						
	<a href="index.php?k=<?php echo $selected_k;?>&action=stopkalivpn"><input class="btn btn-danger kaliservices-button" type="button" value="Stop Kali VPN" name="commit"></a>
</p>