<?php 
$kaliSshStatus			= shell_exec('sh /system/xbin/check-kalissh') == 0	?	' not-running'	:	'';
$kaliDnsmasqStatus		= shell_exec('sh /system/xbin/check-kalidnsmq') == 0	?	' not-running'	:	'';
$kaliHostapdStatus		= shell_exec('sh /system/xbin/check-kalihostapd') == 0	?	' not-running'	:	'';
$kaliVpnStatus			= shell_exec('sh /system/xbin/check-kalivpn') == 0	?	' not-running'	:	'';
$kaliDhcpStatus			= shell_exec('sh /system/xbin/check-kalidhcp') == 0	?	' not-running'	:	'';
//$kaliVncStatus			= shell_exec('sh /system/xbin/check-kalivnc') == 0	?	' not-running'	:	'';
$kaliApacheStatus		= shell_exec('sh /system/xbin/check-kaliapache') == 0	?	' not-running'	:	'';
//$kaliMetaspolitStatus		= shell_exec('sh /system/xbin/check-kalimetasploit') == 0	?	' not-running'	:	'';
?>
<div class="well well-lg description">
	<h3>Kali services</h3>
	<p>Various Kali services you can stop and start via the web interface.</p>
</div>
<p class="kaliservices" id="kalissh">
	<a href="javascript:void(0);" onclick="return StartStopKaliServices('startkalissh');" class="btn btn-success btn-sm">Start Kali SSH</a>						
	<a href="javascript:void(0);" onclick="return StartStopKaliServices('stopkalissh');" class="btn btn-danger btn-sm">Stop Kali SSH</a>
	<span class="service-status<?php echo $kaliSshStatus;?>"></span>
</p>
<p class="kaliservices" id="kalidnsmasq">
	<a href="javascript:void(0);" onclick="return StartStopKaliServices('startkalidnsmasq');" class="btn btn-success btn-sm">Start Kali dnsmasq</a>						
	<a href="javascript:void(0);" onclick="return StartStopKaliServices('stopkalidnsmasq');" class="btn btn-danger btn-sm">Stop Kali dnsmasq</a>
	<span class="service-status<?php echo $kaliDnsmasqStatus; ?>"></span>
</p>
<p class="kaliservices" id="kalihostapd">
	<a href="javascript:void(0);" onclick="return StartStopKaliServices('startkalihostapd');" class="btn btn-success btn-sm">Start Kali Hostapd</a>						
	<a href="javascript:void(0);" onclick="return StartStopKaliServices('stopkalihostapd');" class="btn btn-danger btn-sm">Stop Kali Hostapd</a>
	<span class="service-status<?php echo $kaliHostapdStatus; ?>"></span>
</p>
<p class="kaliservices" id="kalivpn">
	
	<a href="javascript:void(0);" onclick="return StartStopKaliServices('startkalivpn');" class="btn btn-success btn-sm">Start Kali VPN</a>						
	<a href="javascript:void(0);" onclick="return StartStopKaliServices('stopkalivpn');" class="btn btn-danger btn-sm">Stop Kali VPN</a>
	<span class="service-status<?php echo $kaliVpnStatus; ?>"></span>
</p>
<p class="kaliservices" id="kalidhcp">
	<a href="javascript:void(0);" onclick="return StartStopKaliServices('startkalidhcp');" class="btn btn-success btn-sm">Start Kali DHCP</a>						
	<a href="javascript:void(0);" onclick="return StartStopKaliServices('stopkalidhcp');" class="btn btn-danger btn-sm">Stop Kali DHCP</a>
	<span class="service-status<?php echo $kaliDhcpStatus; ?>"></span>
</p>
<?php
/* 
<p class="kaliservices" id="kalivnc">
	<span class="service-status<?php echo $kaliVncStatus; ?>"></span>
	<a href="javascript:void(0);" onclick="return StartStopKaliServices('startkalivnc');" class="btn btn-success btn-sm">Start Kali VNC</a>						
	<a href="javascript:void(0);" onclick="return StartStopKaliServices('stopkalivnc');" class="btn btn-danger btn-sm">Stop Kali VNC</a>
</p>
*/
?>
<p class="kaliservices" id="kaliapache">
	<a href="javascript:void(0);" onclick="return StartStopKaliServices('startkaliapache');" class="btn btn-success btn-sm">Start Kali Apache</a>						
	<a href="javascript:void(0);" onclick="return StartStopKaliServices('stopkaliapache');" class="btn btn-danger btn-sm">Stop Kali Apache</a>
	<span class="service-status<?php echo $kaliApacheStatus; ?>"></span>
</p>
<?php
/* 
<p class="kaliservices" id="kalimetasploit">
	<span class="service-status<?php echo $kaliMetaspolitStatus; ?>"></span>
	<a href="javascript:void(0);" onclick="return StartStopKaliServices('startkalimetasploit');" class="btn btn-success btn-sm">Start Metasploit</a>						
	<a href="javascript:void(0);" onclick="return StartStopKaliServices('stopkalimetasploit');" class="btn btn-danger btn-sm">Stop Metasploit</a>
</p>
*/
?>
