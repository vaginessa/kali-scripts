<div class="well well-lg description">
	<h3>Kali services</h3>
	<p>Various Kali services you can stop and start via the web interface.</p>
</div>
<p class="kaliservices" id="kalissh">
	<a href="javascript:void(0);" onclick="return StartStopKaliServices('startkalissh');" class="btn btn-success btn-sm">Start Kali SSH</a>						
	<a href="javascript:void(0);" onclick="return StartStopKaliServices('stopkalissh');" class="btn btn-danger btn-sm">Stop Kali SSH</a>
</p>
<p class="kaliservices" id="kalidnsmasq">
	<a href="javascript:void(0);" onclick="return StartStopKaliServices('startkalidnsmasq');" class="btn btn-success btn-sm">Start Kali dnsmasq</a>						
	<a href="javascript:void(0);" onclick="return StartStopKaliServices('stopkalidnsmasq');" class="btn btn-danger btn-sm">Stop Kali dnsmasq</a>
</p>
<p class="kaliservices" id="kalihostapd">
	<a href="javascript:void(0);" onclick="return StartStopKaliServices('startkalihostapd');" class="btn btn-success btn-sm">Start Kali Hostapd</a>						
	<a href="javascript:void(0);" onclick="return StartStopKaliServices('stopkalihostapd');" class="btn btn-danger btn-sm">Stop Kali Hostapd</a>
</p>
<p class="kaliservices" id="kalivpn">
	<a href="javascript:void(0);" onclick="return StartStopKaliServices('startkalivpn');" class="btn btn-success btn-sm">Start Kali VPN</a>						
	<a href="javascript:void(0);" onclick="return StartStopKaliServices('stopkalivpn');" class="btn btn-danger btn-sm">Stop Kali VPN</a>
</p>
<p class="kaliservices" id="kalidhcp">
	<a href="javascript:void(0);" onclick="return StartStopKaliServices('startkalidhcp');" class="btn btn-success btn-sm">Start Kali DHCP</a>						
	<a href="javascript:void(0);" onclick="return StartStopKaliServices('stopkalidhcp');" class="btn btn-danger btn-sm">Stop Kali DHCP</a>
</p>
<p class="kaliservices" id="kalivnc">
	<a href="javascript:void(0);" onclick="return StartStopKaliServices('startkalivnc');" class="btn btn-success btn-sm">Start Kali VNC</a>						
	<a href="javascript:void(0);" onclick="return StartStopKaliServices('stopkalivnc');" class="btn btn-danger btn-sm">Stop Kali VNC</a>
</p>
<p class="kaliservices" id="kaliapache">
	<a href="javascript:void(0);" onclick="return StartStopKaliServices('startkaliapache');" class="btn btn-success btn-sm">Start Kali Apache</a>						
	<a href="javascript:void(0);" onclick="return StartStopKaliServices('stopkaliapache');" class="btn btn-danger btn-sm">Stop Kali Apache</a>
</p>
