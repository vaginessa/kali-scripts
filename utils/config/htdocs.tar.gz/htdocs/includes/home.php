<div class="well well-lg description">
	<h3>Nethunter Web Panel</h3>
	<p>This is the NetHunter web panel, geared at making it easier to execute attacks and control services. The panel on the left hand side contains a few links to useful commands, settings and macros. If you have any suggestions for additional features, contact us!<br /><br />
<b>Most configurations will work out of the box</b>, or require minimal tweaking. Make sure you read more about these attacks to get them working perfectly. The Kali NetHunter, like any other tool, takes a while to get used to!

</p>
</div>
