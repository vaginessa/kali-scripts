<div class="well well-lg description">
	<h3>Nethunter Web Panel</h3>
	<p>This is the NetHunter web panel, geared at making it easier to execute attacks and control services. The panel on the left hand side contains a few links to useful commands, settings and macros. If you have any suggestions for additional features, contact us!<br /><br />
<b>Most configurations will work out of the box</b>, or require minimal tweaking. Make sure you read more about these attacks to get them working perfectly. The Kali NetHunter, like any other tool, takes a while to get used to!
</p>
</div>
<h4> Current interfaces</h4>
<pre>
<?php echo shell_exec("netcfg |grep UP |grep -v ^lo|awk -F\" \" '{print $1\"\t\" $3}'"); ?>
</pre>
<h4> External IP Address</h4>

<div class="well well-sm" id="external-ip">
	<a href="javascript:void(0);" onclick="return getExternalIp();" class="btn btn-success btn-sm" id="external-ip-btn">Get External IP</a>
</div>