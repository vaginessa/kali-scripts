<div class="well well-lg description">
	<h3>Nethunter Web Panel</h3>
	<p>This is the NetHunter web panel, geared at making it easier to execute attacks and control services.</p>
</div>
