<div class="well well-lg description">
	<h3>Nethunter Panel</h3>
	<p>Bla bla bla</p>
</div>