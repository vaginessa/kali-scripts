<?php
if (!defined('sec')) {
	die('Try harder!');
}
if (isset($_POST['ajax']) && isset($_POST['action'])) {
	$aaction = trim(strip_tags($_POST['action']));
	switch($aaction):
	case 'startmana':
		$o = shell_exec('start-mana &> /sdcard/htdocs/mana.log &');
	$res = array('status' => 100, 'message' => 'Mana started.');
	break;
	case 'stopmana':
		$o = shell_exec('stop-mana');
		$res = array('status' => 100, 'message' => 'Mana stopped.');
		break;
	case 'starthostapd':
		$o = shell_exec('start-hostapd');
		$res = array('status' => 100, 'message' => 'Hostapd started.');
		break;
	case 'stophostapd':
		$o = shell_exec('stop-hostapd');
		$res = array('status' => 100, 'message' => 'Hostapd stopped.');
		break;
	case 'startdnsmasq':
		$o = shell_exec('start-dnsmasq');
		$res = array('status' => 100, 'message' => 'Dnsmasq started.');
		break;
	case 'stopdnsmasq':
		$o = shell_exec('stop-dnsmasq');
		$res = array('status' => 100, 'message' => 'Dnsmasq stopped.');
		break;
	case 'startbadusb':
		$o = shell_exec('start-badusb &> /sdcard/htdocs/badusb.log &');
		$res = array('status' => 100, 'message' => 'Attack started.');
		break;
	case 'stopbadusb':
		$o = shell_exec('stop-badusb');
		$res = array('status' => 100, 'message' => 'Attack stopped.');
		break;
	case 'startdhcp':
		$o = shell_exec('start-dhcp');
		$res = array('status' => 100, 'message' => 'DHCP service started.');
		break;
	case 'stopdhcp':
		$o = shell_exec('stop-dhcp');
		$res = array('status' => 100, 'message' => 'DHCP service stopped.');
		break;
	case 'iptaction1':
		$o = shell_exec('iptables-nat-simple');
		$res = array('status' => 100, 'message' => 'IP tables action 1 started.');
		break;
	/*	
	case 'iptaction2':
		$o = shell_exec('iptables-nat-full');
		$res = array('status' => 100, 'message' => 'IP tables action 2 started.');
		break;
	*/
	case 'iptflush':
		$o = shell_exec('iptables-flush');
		$res = array('status' => 100, 'message' => 'IP tables flushed');
		break;
	case 'startkalissh';
	$o = shell_exec('start-ssh');
	$res = array('status' => 100, 'message' => 'Kali ssh started.');
	break;
	case 'stopkalissh';
	$o = shell_exec('stop-ssh');
	$res = array('status' => 100, 'message' => 'Kali ssh stopped.');
	break;
	case 'startkalidnsmasq';
	$o = shell_exec('start-dnsmasq');
	$res = array('status' => 100, 'message' => 'Kali dnsmasq started.');
	break;
	case 'stopkalidnsmasq';
	$o = shell_exec('stop-dnsmasq');
	$res = array('status' => 100, 'message' => 'Kali dnsmasq stopped.');
	break;
	case 'startkalihostapd';
	$o = shell_exec('start-hostap');
	$res = array('status' => 100, 'message' => 'Kali Hostapd started.');
	break;
	case 'stopkalihostapd';
	$o = shell_exec('stop-hostap');
	$res = array('status' => 100, 'message' => 'Kali Hostapd stopped.');
	break;
	case 'startkalivpn';
	$o = shell_exec('start-vpn');
	$res = array('status' => 100, 'message' => 'Kali VPN started.');
	break;
	case 'stopkalivpn';
	$o = shell_exec('stop-vpn');
	$res = array('status' => 100, 'message' => 'Kali VPN stopped.');
	break;
	case 'startkalidhcp';
	$o = shell_exec('start-dhcp');
	$res = array('status' => 100, 'message' => 'DHCP started.');
	break;
	case 'stopkalidhcp';
	$o = shell_exec('stop-dhcp');
	$res = array('status' => 100, 'message' => 'DHCP stopped.');
	break;
	case 'startkalivnc';
	$o = shell_exec('start-vnc');
	$res = array('status' => 100, 'message' => 'VNC stopped.');
	break;
	case 'stopkalivnc';
	$o = shell_exec('stop-vnc');
	$res = array('status' => 100, 'message' => 'VNC stopped.');
	break;
	case 'startkaliapache';
	$o = shell_exec('start-apache');
	$res = array('status' => 100, 'message' => 'Apache started.');
	break;
	case 'stopkaliapache';
	$o = shell_exec('stop-apache');
	$res = array('status' => 100, 'message' => 'Apache stopped.');
	break;
	case 'resetusb';
	$o = shell_exec('stop-badusb');
	$res = array('status' => 100, 'message' => 'Resetting USB.');
	break;
	case 'startkalimetasploit':
		$o = shell_exec('');
		$res = array('status' => 100, 'message' => 'Metasploit started.');
		break;
	case 'stopkalimetasploit':
		$o = shell_exec('');
		$res = array('status' => 100, 'message' => 'Metasploit stopped.');
		break;
	default:
		$res = array('status' => 200, 'message' => 'Unrecognized action!');
		break;
		endswitch;
		echo json_encode($res);
		die;
}
